#include "m4.h"
#include <chrono>

#define TIME_LIMIT 30

//std::vector<unsigned> traveling_courier(const std::vector<DeliveryInfo>& deliveries, const std::vector<unsigned>& depots) {
//
//    // Grab the first depot to start with 
//    unsigned first_depot;
////    if (depots.size() > 1) {
////        first_depot = depots[1];
////    } else {
////        first_depot = depots[0];
////    }
//    std::vector<unsigned> path_return;
//    std::vector<unsigned> vector1;
//    bool first_run = true;
//
//    //this loops make sure if there is no path between start depot to first pickup, moveon to next start depot and retry
//    for (unsigned j = 0; j < depots.size(); j++) {
//        first_depot = depots[j];
//        path_return = find_path_between_intersections(first_depot, deliveries[0].pickUp);
//        if (path_return.size() != 0) {
//            break;
//        }//else empty path try next depot to start
//    }
//
//    unsigned total_deliveries = deliveries.size();
//    
//
//
//   // path_return = find_path_between_intersections(first_depot, deliveries[0].pickUp);
//    // Once the depot selected, loop over all the deliveries 
//
//    for (unsigned i = 0; i < total_deliveries - 1; i++) {
//
//        DeliveryInfo deliveries_struct1 = deliveries[i];
//        DeliveryInfo deliveries_struct2 = deliveries[i + 1];
//
//        //if (first_run){
//        //Select the depot and the first starting point 
//        //  path_return = find_path_between_intersections (first_depot, deliveries_struct1.pickUp);
//        //}
//
//        // Call the dijksstra function for each set
//        //std::vector<unsigned> find_path_between_intersections(unsigned 
//        // intersect_id_start, unsigned intersect_id_end);
//
//        vector1 = find_path_between_intersections(deliveries_struct1.pickUp, deliveries_struct1.dropOff);
//
//        //if (first_run){
//
//        path_return.insert(path_return.end(), vector1.begin(), vector1.end());
//        //}
//        //else {
//
//        //}
//
//        vector1 = find_path_between_intersections(deliveries_struct1.dropOff, deliveries_struct2.pickUp);
//
//        path_return.insert(path_return.end(), vector1.begin(), vector1.end());
//
//
//        first_run = false;
//
//
//    }
//    //deliveries.
//    DeliveryInfo deliveries_struct1 = deliveries[total_deliveries - 1];
//    // Making the las delivery 
//    vector1 = find_path_between_intersections(deliveries_struct1.pickUp, deliveries_struct1.dropOff);
//    path_return.insert(path_return.end(), vector1.begin(), vector1.end());
//    // Return the truck back to its place 
//    vector1 = find_path_between_intersections(deliveries_struct1.dropOff, first_depot);
//    path_return.insert(path_return.end(), vector1.begin(), vector1.end());
//
//
//
//    return path_return;
//
//}


//unordered_map <unsigned, set<unsigned> > pickupToDropOffMap;
//unordered_map <unsigned, set<unsigned> > dropOffToPickupMap;
//set<unsigned> totalPickups; //all the unique pickups intersections;
// set<unsigned> allDropOffIdsSet;//all unique drop off intersections
//vector<unsigned> pickupsDone;






unordered_map <unsigned, set<unsigned> > pickupToDropOffMap;
unordered_map <unsigned, set<unsigned> > dropOffToPickupMap;
vector <unsigned> best_path_multistart;
vector <unsigned> totalPathForM4;

double best_path_multistart_time;



set<unsigned> allDropOffIdsSet;
vector<unsigned> pickupsDone;
vector<bool>didPickupVec;

std::vector<unsigned> traveling_courier(const std::vector<DeliveryInfo>& deliveries, const std::vector<unsigned>& depots) {

    auto startTime = chrono::high_resolution_clock::now();
    bool first_run = true;

    double lowestDist = DBL_MAX;
    best_path_multistart_time = DBL_MAX;
    unsigned lowestNextInterId;

    vector <unsigned> dropOffsLaterVec;
    set <unsigned>::iterator myIter;
    double distOfComp = 0;
    unsigned curInterId;

    LatLon inter1, inter2;

    set<unsigned> pickupsSet;

    vector<unsigned> segIdsToJoin;
    bool reAddDropOffs = false;




    unsigned pickup, dropOff;

    set <unsigned> allDropOffandPickupIdsSet;
    set <unsigned> multi_valid_startpoints;


    vector <unsigned> path_return;


//will use every deopt as starting point and give out the one that is best overall
    for (unsigned it = 0; it < depots.size(); it++) {
        // Reset the situation when depot is changed 
        bool no_path_found = false;

        auto currentTime = chrono::high_resolution_clock::now();
        auto wallClock =
                chrono::duration_cast<chrono::duration<double> > (currentTime - startTime);


        if (wallClock.count() > 0.9 * TIME_LIMIT) {

            return best_path_multistart;

        }

        unsigned startIntersection = depots[it];
        vector<bool> didPickupVec_(numOfIntersections, false);


        pickupToDropOffMap.clear();
        dropOffToPickupMap.clear();
        totalPathForM4.clear();
        allDropOffIdsSet.clear();
        pickupsDone.clear();
        dropOffsLaterVec.clear();



        for (unsigned i = 0; i < deliveries.size(); i++) {

            pickup = deliveries[i].pickUp;
            dropOff = deliveries[i].dropOff;

            allDropOffandPickupIdsSet.insert(dropOff);
            allDropOffandPickupIdsSet.insert(pickup);

            pickupToDropOffMap[pickup].insert(dropOff);

            dropOffToPickupMap[dropOff].insert(pickup);


        }
        
        int numOfDropOffsLeft = dropOffToPickupMap.size();

       //run the loop till al the dropOffs are mad
        while (numOfDropOffsLeft != 0) {

            //checking if function stays within 30s time limit otherwise give best available path
            if (wallClock.count() > 0.7 * TIME_LIMIT) {
                return best_path_multistart;

            }

            //if the exploring set is empty after you can't find the path to any available then break
            //and try next depot for a complete path
            
            if (allDropOffandPickupIdsSet.size() == 0) {
                
                no_path_found = true;
                break;
            }
            
            
            for (myIter = allDropOffandPickupIdsSet.begin(); myIter != allDropOffandPickupIdsSet.end(); myIter++) {
                curInterId = *myIter;

                inter1 = getIntersectionPosition(startIntersection);

                inter2 = getIntersectionPosition(curInterId);

                distOfComp = find_distance_squared_between_two_points(inter1, inter2);

                if (allDropOffandPickupIdsSet.size() == 1) {//means last element remaining so force to use the last remaining intersection 

                    lowestDist = distOfComp;
                    lowestNextInterId = curInterId;

                } else {
                    //compare the smallest value and use the nearest intersection to go to
                    if (distOfComp < lowestDist) {
                        lowestDist = distOfComp;
                        lowestNextInterId = curInterId;


                    }
                }
            }

            //have the smallest/nearest pickup or dropOff point, now check which is that
            //checking first if the path between two intersections exists or not
            segIdsToJoin = find_path_between_intersections(startIntersection, lowestNextInterId);

            // Means the path exist between 2 points:
            if (segIdsToJoin.size() != 0) {

                // Search map(DROPoffs) if lowest_this point is present as dropOff
                unordered_map<unsigned, set<unsigned> >::iterator iter1 = dropOffToPickupMap.find(lowestNextInterId);

                // Lowest point found is a dropoff
                if (iter1 != dropOffToPickupMap.end()) {


                    if (pickupsDone.size() != 0) {

                        //means you have some dropOff now check if you have all the pickups for this dropOff

                        //Getting the pick_ups set from the map
                        pickupsSet = iter1->second;

                        int numOfPickups = 0;


                        for (myIter = pickupsSet.begin(); myIter != pickupsSet.end(); myIter++) {

                            if (didPickupVec_[(*myIter)] == true) {

                                numOfPickups++;

                            }
                        }
                        if (numOfPickups == pickupsSet.size()) {

                            //have all the pickups for this dropOff make a path to it


                            if (totalPathForM4.size() == 0) {

                                // means the first run. Join id to depot 
                                totalPathForM4 = segIdsToJoin;
                            } else {
                                //Not first run, needs concatenations to original vector
                                totalPathForM4.insert(totalPathForM4.end(), segIdsToJoin.begin(), segIdsToJoin.end()); //joining path to overall path

                            }

                            //remove this from exploring set as you visited this intersection
                            
                            set<unsigned>::iterator iterToDel = allDropOffandPickupIdsSet.find(lowestNextInterId);

                            if (iterToDel != allDropOffandPickupIdsSet.end()) {
                                //dELETE ENTRY FROM THE SET 

                                allDropOffandPickupIdsSet.erase(iterToDel);

                                numOfDropOffsLeft--; //subtract the total drop Offs to do!!

                                //remove this from the map
                                auto itti = dropOffToPickupMap.find(lowestNextInterId);

                                dropOffToPickupMap.erase(itti);

                                //this point now becomes the next point to start exploring from
                                startIntersection = lowestNextInterId;


                            }





                        } else {
                            //we didn't have all the packges to deliver for this dropOff
                            //put this dropOff in later vector and once you're done everything put it back

                            set<unsigned>::iterator iterToDel = allDropOffandPickupIdsSet.find(lowestNextInterId);

                            if (iterToDel != allDropOffandPickupIdsSet.end()) {

                                allDropOffandPickupIdsSet.erase(iterToDel);

                                dropOffsLaterVec.push_back(lowestNextInterId);

                                reAddDropOffs = true;

                                lowestDist = DBL_MAX;

                                continue;
                            }


                        }


                    } else { //PICKUPS DONE SIZE = 0
                        
                        //means you can't deliver to a point if you don't have any packages
                        
                        set<unsigned>::iterator iterToDel = allDropOffandPickupIdsSet.find(lowestNextInterId);

                        lowestDist = DBL_MAX;


                        if (iterToDel != allDropOffandPickupIdsSet.end()) {

                            allDropOffandPickupIdsSet.erase(iterToDel);
                            dropOffsLaterVec.push_back(lowestNextInterId);

                            reAddDropOffs = true;
                            //restart the procedure to get the next intersection
                            continue;
                        }

                    }




                }

                // THE POINT FOUND WAS NOT A DROP OFF -> CHECK IF IT IS A PICK UP 
                
                unordered_map<unsigned, set<unsigned> >::iterator iter2 = pickupToDropOffMap.find(lowestNextInterId);

                if (iter2 != pickupToDropOffMap.end()) {
                    //intersection you got is pickup

                    // Updating the value of the pickUP vector
                    didPickupVec_[lowestNextInterId] = true;

                    pickupsDone.push_back(lowestNextInterId);

                    startIntersection = lowestNextInterId;

                    set<unsigned>::iterator iterToDel = allDropOffandPickupIdsSet.find(lowestNextInterId);

                    if (iterToDel != allDropOffandPickupIdsSet.end()) {

                        allDropOffandPickupIdsSet.erase(iterToDel);

                        if (totalPathForM4.size() == 0) {

                            totalPathForM4 = segIdsToJoin;

                        } else {

                            totalPathForM4.insert(totalPathForM4.end(), segIdsToJoin.begin(), segIdsToJoin.end()); //joining path to overall path

                        }
                    }



                }

            } else {


                set<unsigned>::iterator iterToDel = allDropOffandPickupIdsSet.find(lowestNextInterId);

                if (iterToDel != allDropOffandPickupIdsSet.end()) {

                    allDropOffandPickupIdsSet.erase(iterToDel);

                    dropOffsLaterVec.push_back(lowestNextInterId);
                    //restart the proceudre to get second best thing
                    reAddDropOffs = true;
                    lowestDist = DBL_MAX;

                    continue;
                }

            }



            //resetting the comparison reference distance
            lowestDist = DBL_MAX;

            //add the dropOffs removed back if flag is like true!!
            if (reAddDropOffs == true) {

                for (unsigned k = 0; k < dropOffsLaterVec.size(); k++) {
                    allDropOffandPickupIdsSet.insert(dropOffsLaterVec[k]);
                }
                dropOffsLaterVec.clear();
            }

        }

        if (!no_path_found) { // Means don't have to evaluate these things if no path found 



            //sticking the ending depot

            vector <unsigned> testVec;
            double pathTravelTime = DBL_MAX;
            double tempTime = 0;



            // Optimizing the ending depot
            for (unsigned k = 0; k < depots.size(); k++) {
                segIdsToJoin = find_path_between_intersections(lowestNextInterId, depots[k]);
                if (segIdsToJoin.size() != 0) {
                    tempTime = compute_path_travel_time(segIdsToJoin);

                    if (tempTime < pathTravelTime) {
                        pathTravelTime = tempTime;
                        testVec = segIdsToJoin;
                    }
                }
            }


            // This is the final path that I will have to save
            // Compare with results form the other staring points
            // Output the best answer 

            totalPathForM4.insert(totalPathForM4.end(), testVec.begin(), testVec.end());

            if (first_run) {
                best_path_multistart = totalPathForM4;
                best_path_multistart_time = compute_path_travel_time(totalPathForM4);
            } else {
                double curPathTime = compute_path_travel_time(totalPathForM4);
                //compare the travel times before updating the best path 
                if (curPathTime < best_path_multistart_time) {
                    //Update path info 


                    best_path_multistart = totalPathForM4;
                    best_path_multistart_time = compute_path_travel_time(totalPathForM4);


                }

            }



            first_run = false;

        }
    }


    return best_path_multistart;



}