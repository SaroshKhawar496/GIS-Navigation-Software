
#ifndef MAPLODER_H
#define MAPLODER_H

#include "m2.h"
#include "m1.h"
#include <iostream>
using namespace std;


void mapInitializer();

#endif /* MAPLODER_H */

