
#include "adjacentIntersection.h"

std::vector<adjIntersectionRet> adjacent_intersections(unsigned intersection_id) {


    //temp variables ------------------------------
    //    std::set <unsigned> tmpSet;

    std::vector<adjIntersectionRet> adjacent_inter;

    StreetSegmentInfo streetSeg_struct;

    unsigned segId;

    //--------------------------------------------------

    unsigned intersections_count = getIntersectionStreetSegmentCount(intersection_id);

    // Have to check for a 1 way road 
    unsigned streetId;
    
    for (unsigned i = 0; i < intersections_count; i++) {

        adjIntersectionRet fillStr;
        //segId is street segment id for that intersection
        segId = getIntersectionStreetSegment(intersection_id, i);
        //Using the street segment id to get all the info
        // Have to check for street segment connections and 1-ways
        streetSeg_struct = streetSegmentInformationVec[segId];

        if (streetSeg_struct.from == intersection_id) {
            //i.e adjacent intersection is a "to", hence, connected 
            // 
            //push in the street id in it make a strtucutre return vector

            if (streetSeg_struct.to == intersection_id) {

            } else {
                fillStr.streetId_ = streetSeg_struct.streetID;
                fillStr.segmentId_ = segId;


                fillStr.adjInterId_ = streetSeg_struct.to;
                            adjacent_inter.push_back(fillStr);

            }


        }//For the case if the from & to are flipped but the road is 2-way

        else if (streetSeg_struct.to == intersection_id) {
            //Segment may start from the other end but if it is 
            // !1-way, still adjacent 
            if (streetSeg_struct.oneWay == true) {
                
                
            } 
            
            else {

                if (streetSeg_struct.from == intersection_id) {

                } else {

                    fillStr.streetId_ = streetSeg_struct.streetID;
                    fillStr.segmentId_ = segId;
                    fillStr.adjInterId_ = streetSeg_struct.from;

                    adjacent_inter.push_back(fillStr);
                }

            }
        }

    }



    //putting data of set back into vector
    //  adjacent_inter.assign(tmpSet.begin(), tmpSet.end());

    return adjacent_inter;

}
