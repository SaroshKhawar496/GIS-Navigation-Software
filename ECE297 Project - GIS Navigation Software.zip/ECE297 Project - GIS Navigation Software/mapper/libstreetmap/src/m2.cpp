#include "m2.h"
#include "m3.h"
#include "StreetsDatabaseAPI.h"
#define MAX_TEXT_ARRAY_SIZE 50

using namespace std;


unsigned idx1, idx2;
string command;
bool run = false;


void drawPath(unsigned id1, unsigned id2);
int numOfClicks = 0;

Point X, Y;
vector <unsigned> pathVec;
bool reDrawPath = false;
bool resetDraw = false;

bool clearStartInter_InterClix = false;

bool showFindPath = false;
bool clearEndInter_InterClix = false;

bool showPOIPath = false;


bool showInters_Path = false;

//unsigned id1, id2;
bool clickedOnce = false;
bool clickedTwice = false;
//bool clearStartInter= false;

LatLon clickPos;
unsigned closestInter;
LatLon interPos;
Point interPosXY;
Point interPosXY2;
unsigned id1;

void delay(long milliseconds) {
    // if you would like to use this function in your
    // own code you will need to #include <chrono> and
    // <thread>
    std::chrono::milliseconds duration(milliseconds);
    std::this_thread::sleep_for(duration);
}

// Callbacks for event-driven window handling.
void drawscreen(void);
void act_on_new_button_func(void (*drawscreen_ptr) (void));

//to find hotels press the button
void act_on_Search_Hotel_buttonPress(void (*drawscreen_ptr) (void));
void act_on_Switch_Map_buttonPress(void (*drawscreen_ptr) (void));
void act_on_FindPath_buttonPress(void (*drawscreen_ptr) (void));

void act_on_PathFinding_buttonPress(float x1, float y1, t_event_buttonPressed event); //,void (*drawscreen_ptr) (void));


void act_on_button_press(float x, float y, t_event_buttonPressed event);

void act_on_mouse_move(float x, float y);
void act_on_key_press(char c, int keysym);
void act_on_reset_clicks(void (*drawscreen_ptr) (void));

void act_on_intersection_clicks(void (*drawscreen_ptr) (void));

void act_on_help(void (*drawscreen_ptr) (void));

//variables to hold and decide the max and min Lat and Lon

LatLon minLatLon_, MaxLatLon_;
float Min_Lat, Max_Lat, Min_Lon, Max_Lon;

t_bound_box initial_coords;

bool findPressed = false;
vector<Point> highlightInterPts;

Point conv_LatLon_to_XY(LatLon point1) {
    //Two variables to hold calculated (x,y) coordinates of given LatLon Points
    //compute latitude average between given two points

    Point P1;
    double latAverage = ((MaxLatLon_.lat * DEG_TO_RAD) + (minLatLon_.lat * DEG_TO_RAD)) / 2;

    P1.x = ((point1.lon * DEG_TO_RAD) * cos(latAverage));

    P1.y = (point1.lat * DEG_TO_RAD);
    return P1;
}

void setBounds() {

    minLatLon_ = getIntersectionPosition(0);
    MaxLatLon_ = getIntersectionPosition(0);

    for (unsigned j = 0; j < numOfIntersections; j++) {
        LatLon curLatLon = getIntersectionPosition(j);
        if (curLatLon.lat > MaxLatLon_.lat) {
            MaxLatLon_.lat = curLatLon.lat;
        }

        if (curLatLon.lon > MaxLatLon_.lon) {
            MaxLatLon_.lon = curLatLon.lon;
        }
        if (curLatLon.lat < minLatLon_.lat) {
            minLatLon_.lat = curLatLon.lat;
        }
        if (curLatLon.lon < minLatLon_.lon) {
            minLatLon_.lon = curLatLon.lon;
        }



    }

    Point maxLatLoninXY = conv_LatLon_to_XY(MaxLatLon_);
    Point minLatLoninXY = conv_LatLon_to_XY(minLatLon_);

    //Point.y is lat and POint.x is lon
    Min_Lat = minLatLoninXY.y;

    Max_Lat = maxLatLoninXY.y;

    Min_Lon = minLatLoninXY.x;

    Max_Lon = maxLatLoninXY.x;


}

void draw_map() {

    setBounds();

    initial_coords = t_bound_box(Min_Lon, Min_Lat, Max_Lon, Max_Lat);

    /**************** initialize display **********************/

    // Set the name of the window (in UTF-8), with white background.
    init_graphics("THE MAP", WHITE); // you could pass a t_color RGB triplet instead

    // Set-up coordinates. The coordimnates passed in define what coordinate
    // limits you want to use; this coordinate system is mapped to fill
    // the screen.
    set_visible_world(initial_coords);
    create_button("Window", "Switch Map", act_on_Switch_Map_buttonPress);


    create_button("Switch Map", "Find", act_on_new_button_func); // name is UTF-8

    create_button("Find", "Find Path", act_on_FindPath_buttonPress);

    create_button("Find Path", "Search Hotel", act_on_Search_Hotel_buttonPress);



    create_button("Switch Map", "Reset Screen", act_on_reset_clicks);

    create_button("Reset Screen", "Route InterIds", act_on_intersection_clicks);

    create_button("Search Hotel", "Help", act_on_help);

    //    act_on_PathFinding_buttonPress;
    //first arg was act on key press

    //-------------------------------------------------------------
    //returns the segment ids

    event_loop(act_on_button_press, act_on_mouse_move, act_on_key_press, drawscreen);



    //    setlinewidth(1);
    //    setlinestyle(SOLID);
    //    setcolor(PURPLE);
    //    drawline(X.x, X.y, Y.x, Y.y);
    //



    set_keypress_input(true);
    set_mouse_move_input(true);

    //close_graphics();

    std::cout << "Graphics closed down.\n";

}

void drawStreetsHelper(unsigned stSegIndex, unsigned cuvPts, Point inter_Pos1, Point inter_Pos2) {

    vector <Point> drawVec;

    drawVec.push_back(inter_Pos1);



    if (cuvPts > 0) {

        for (unsigned i = 0; i < cuvPts; i++) {

            LatLon CurPos = getStreetSegmentCurvePoint(stSegIndex, i);
            Point cuvPosXY = conv_LatLon_to_XY(CurPos);
            drawVec.push_back(cuvPosXY);
        }
        //LatLon

        drawVec.push_back(inter_Pos2);

        for (unsigned i = 0; i < drawVec.size() - 1; i++) {
            //setcolor(BLACK);
            setlinestyle(SOLID);
            //setlinewidth(1);
            drawline(drawVec[i].x, drawVec[i].y, drawVec[i + 1].x, drawVec[i + 1].y);

        }

    } else {

        //setlinewidth(1);
        setlinestyle(SOLID);

        //setcolor(BLACK);
        drawline(inter_Pos1.x, inter_Pos1.y, inter_Pos2.x, inter_Pos2.y);


    }

}

void drawPathHelper(unsigned stSegIndex, unsigned cuvPts, Point inter_Pos1, Point inter_Pos2) {

    vector <Point> drawVec;

    drawVec.push_back(inter_Pos1);



    if (cuvPts > 0) {

        for (unsigned i = 0; i < cuvPts; i++) {

            LatLon CurPos = getStreetSegmentCurvePoint(stSegIndex, i);
            Point cuvPosXY = conv_LatLon_to_XY(CurPos);
            drawVec.push_back(cuvPosXY);
        }
        //LatLon

        drawVec.push_back(inter_Pos2);

        for (unsigned i = 0; i < drawVec.size() - 1; i++) {
            setcolor(PINK);
            setlinestyle(SOLID);
            setlinewidth(2);
            drawline(drawVec[i].x, drawVec[i].y, drawVec[i + 1].x, drawVec[i + 1].y);

        }

    } else {

        setlinewidth(2);
        setlinestyle(SOLID);

        setcolor(BLACK);
        drawline(inter_Pos1.x, inter_Pos1.y, inter_Pos2.x, inter_Pos2.y);


    }

}





//****************************DRAW FEATURE*********************************
// The function distinguishes between the polygon and line to be drawn 

void draw_feature(int feature_point_count, int i, int feature_type) {



    vector <Point> draw_line_features;
    bool is_not_poly = false;


    t_point array_points[feature_point_count];

    for (int j = 0; j < feature_point_count; j++) {


        LatLon Xpress = getFeaturePoint(i, j);
        Point Lonley = conv_LatLon_to_XY(Xpress);

        // If feature is made of lines (Not a Polygon)
        if (feature_type == 4 || feature_type == 6 || feature_type == 10) {
            draw_line_features.push_back(Lonley);
            is_not_poly = true;
        } else {
            array_points[j] = {Lonley.x, Lonley.y};
        }


    }

    if (is_not_poly) {

        for (unsigned i = 0; i < draw_line_features.size() - 1; i++) {

            drawline(draw_line_features[i].x, draw_line_features[i].y, draw_line_features[i + 1].x, draw_line_features[i + 1].y);

        }
    } else {

        setfontsize(10);
        fillpoly(array_points, feature_point_count);
    }

}


// using red and green rectangles to show one way direction
// red shows "from" and green shows "to" one way directions

void showOneWay(unsigned cuvPts, Point inter_Pos1, Point inter_Pos2, unsigned segId) {
    //currently work for straight segments 
    float xdelta = 2e-7;
    float ydelta = 1e-7;

    if (cuvPts == 0) {
        Point lineCen;
        lineCen.x = (inter_Pos1.x + inter_Pos2.x) / 2;
        lineCen.y = (inter_Pos1.y + inter_Pos2.y) / 2;

        //red rectangle is showing from direction
        setlinestyle(SOLID);
        setcolor(RED);


        /* (x1,y1) and (x2,y2) are diagonally opposed corners */

        drawrect(lineCen.x - xdelta, lineCen.y - ydelta, lineCen.x + xdelta, lineCen.y + ydelta);

        // green rectangle is showing to direction
        setcolor(GREEN);
        Point rect2;

        rect2.x = (lineCen.x + inter_Pos2.x) / 2;
        rect2.y = (lineCen.y + inter_Pos2.y) / 2;

        drawrect(rect2.x - xdelta, rect2.y - ydelta, rect2.x + xdelta, rect2.y + ydelta);

    }// one way indication for curved segments
    else {
        LatLon CurPos = getStreetSegmentCurvePoint(segId, 0);
        Point curPosXY = conv_LatLon_to_XY(CurPos);
        Point lineCen;
        lineCen.x = (inter_Pos1.x + curPosXY.x) / 2;
        lineCen.y = (inter_Pos1.y + curPosXY.y) / 2;

        //red rectangle is showing from direction
        setlinestyle(SOLID);
        setcolor(RED);

        /* (x1,y1) and (x2,y2) are diagonally opposed corners */
        drawrect(lineCen.x - xdelta, lineCen.y - ydelta, lineCen.x + xdelta, lineCen.y + ydelta);

        // green rectangle is showing to direction
        setcolor(GREEN);
        Point rect2;

        rect2.x = (lineCen.x + curPosXY.x) / 2;
        rect2.y = (lineCen.y + curPosXY.y) / 2;

        drawrect(rect2.x - xdelta, rect2.y - ydelta, rect2.x + xdelta, rect2.y + ydelta);


    }

}

void drawStreets() {

    t_bound_box curBox = get_visible_world();
    float zoomLvl = initial_coords.get_width() / curBox.get_width();

    for (unsigned j = 0; j < numOfStreetSegs; j++) {

        StreetSegmentInfo curSeg = streetSegmentInformationVec[j];

        unsigned intersection1 = curSeg.from;
        unsigned intersection2 = curSeg.to;

        LatLon tmpPosInter1 = intersectionPositionVec[intersection1];


        //Point.y is lat and POint.x is lon

        Point interPos1 = conv_LatLon_to_XY(tmpPosInter1);

        LatLon tmpPosInter2 = intersectionPositionVec[intersection2];

        Point interPos2 = conv_LatLon_to_XY(tmpPosInter2);


        unsigned numOfCurvePts = curSeg.curvePointCount;
        bool roadOneWay = curSeg.oneWay;
        float segSpeedLim = curSeg.speedLimit;


        if (segSpeedLim >= 80 && (zoomLvl <= 1.5)) {
            //this color is orange shade for the highways
            setcolor(t_color(0xFB, 0x9E, 0x25));

            setlinewidth(2);
            drawStreetsHelper(j, numOfCurvePts, interPos1, interPos2);

        }

        // chaneg to 1.5 

        if (segSpeedLim >= 60 && (zoomLvl > 1.5)) { //Initially 1.5
            //highways stay orange
            if (segSpeedLim >= 80) {
                //setcolor(t_color(0xFF, 0xA3, 0x47));
                setcolor(t_color(0xFB, 0x9E, 0x25));
                //setcolor(BLACK);

                setlinewidth(3);

            } else {
                //this color is gray for non highway roads
                setcolor(t_color(0xDF, 0xD9, 0xAA));
                //setcolor(BLACK);

                setlinewidth(2);
            }
            drawStreetsHelper(j, numOfCurvePts, interPos1, interPos2);

        }

        // here change to 3 
        if ((segSpeedLim >= 40 && zoomLvl > 3)) {

            //highways stay orange
            if (segSpeedLim >= 80) {

                setcolor(t_color(0xFB, 0x9E, 0x25));

                setlinewidth(4);

            } else {
                setcolor(t_color(0xDF, 0xD9, 0xAA));


                setlinewidth(2);
            }


            drawStreetsHelper(j, numOfCurvePts, interPos1, interPos2);

        }
        // here to 5
        if (zoomLvl > 5) {
            //highways stay orange
            if (segSpeedLim >= 80) {
                //setcolor(t_color(0xFF, 0xA3, 0x47));
                setcolor(t_color(0xFB, 0x9E, 0x25));
                //setcolor(BLACK);

                setlinewidth(5);

            } else {
                setcolor(t_color(0xDF, 0xD9, 0xAA));
                //setcolor(BLACK);

                setlinewidth(2);
            }
            drawStreetsHelper(j, numOfCurvePts, interPos1, interPos2);
        }
        if (roadOneWay == true && zoomLvl >= 40) {
            showOneWay(numOfCurvePts, interPos1, interPos2, j);
        }
    }


}

void drawFeatures(float zoomLvl) {
    for (unsigned i = 0; i < numOfFeatures; i++) {

        // GET the feature's type
        int feature_type = getFeatureType(i);

        // Get the points that make up the polygon 
        unsigned feature_point_count = getFeaturePointCount(i);
        // Making an array of t_points to be given to fill_poly


        if ((feature_type == 2 || feature_type == 3 || feature_type == 5 || feature_type == 8) && zoomLvl > 0) { //zoomLvl > 0

            // All these features are polygons hence, 
            if (feature_type == 3)
                setcolor(LIGHTSKYBLUE);

            else if (feature_type == 5)
                setcolor(WHITE);

            else if (feature_type == 8)
                setcolor(GREEN);

            else if (feature_type == 2)
                setcolor(DARKSLATEBLUE);


            //t_color(0xCB, 0xDF, 0xAA)

            draw_feature(feature_point_count, i, feature_type);
        }

        if ((feature_type == 6) && zoomLvl > 8) {

            setcolor(KHAKI);


            draw_feature(feature_point_count, i, feature_type);

        }


        if ((feature_type == 10) && (zoomLvl > 50)) { //zoomLvl > 13

            setcolor(t_color(0x00, 0x00, 0xCC));
            draw_feature(feature_point_count, i, feature_type);

        }


    }



}

void drawGolfCourses(float zoomLvl) {

    /////////////// GOLF COURSES //////////////////
    if (zoomLvl > 15) {


        //setcolor(RED);
        setlinestyle(DASHED);
        setlinewidth(2);


        settextrotation(0);
        setfontsize(10);
        string golfCourseName;
        //setcolor(RED);
        //cout << "NAmes in m2.cpp\n";
        for (unsigned j = 0; j < GolfCoursePlots.size(); j++) {

            //t_point
            //fillpoly();
            golfCourseName = GolfCoursePlots[j].tags[0].second;
            //cout << golfCourseName << endl;
            vector <Point> tmpVec = GolfCoursePlots[j].coordinatesXYVec;
            setcolor(DARKGREEN);
            unsigned i;

            for (i = 0; i < tmpVec.size() - 1; i++) {

                drawline(tmpVec[i].x, tmpVec[i].y, tmpVec[i + 1].x, tmpVec[i + 1].y);

            }
            setcolor(MAGENTA); //was black
            float boundx = 1e-2;
            float boundy = 1e-2;

            if (zoomLvl > 20) {
                drawtext(tmpVec[0].x, tmpVec[0].y, golfCourseName, boundx, boundy);
            }
        }

    }


}

void drawRunWay(float zoomLvl) {
    //////////////////////////RUNWAY//////////////////////////
    if (zoomLvl > 13) {


        setlinestyle(DASHED);
        setlinewidth(1);


        settextrotation(0);
        setfontsize(10);
        string RunwayName;
        for (unsigned j = 0; j < RunwayPlots.size(); j++) {

            RunwayName = RunwayPlots[j].tags[0].second;
            vector <Point> tmpVec = RunwayPlots[j].coordinatesXYVec;
            setcolor(BLACK);
            unsigned i;

            for (i = 0; i < tmpVec.size() - 1; i++) {

                drawline(tmpVec[i].x, tmpVec[i].y, tmpVec[i + 1].x, tmpVec[i + 1].y);

            }

            float boundx = 1e-2;
            float boundy = 1e-2;

            if (zoomLvl > 20) {
                drawtext(tmpVec[0].x, tmpVec[0].y, RunwayName, boundx, boundy);
            }
        }

    }





}

void drawParks(float zoomLvl) {
    //////////////////PARKS////////////////////// 

    if (zoomLvl > 0) {


        for (unsigned i = 0; i < draw_Parks.size(); i++) {

            unsigned park_id = draw_Parks[i];

            unsigned feature_point_count = getFeaturePointCount(park_id);


            setcolor(t_color(0x87, 0xD2, 0x5B));
            draw_feature(feature_point_count, park_id, 1);


        }


    }

}

void drawRivers(float zoomLvl) {

    /////////////////RIVER////////////////////////

    if (zoomLvl > 8) {


        for (unsigned i = 0; i < draw_River.size(); i++) {

            unsigned River_id = draw_River[i];

            unsigned feature_point_count = getFeaturePointCount(River_id);


            setcolor(LIGHTSKYBLUE);
            draw_feature(feature_point_count, River_id, 4);


        }


    }


}

void drawBuildings(float zoomLvl) {
    /////////////////BUILDINGS //////////////////
    if (zoomLvl > 13) {

        for (unsigned i = 0; i < draw_Buildings.size(); i++) {

            unsigned building_id = draw_Buildings[i];

            unsigned feature_point_count = getFeaturePointCount(building_id);


            setcolor(t_color(0xDC, 0xE4, 0xE9));
            draw_feature(feature_point_count, building_id, 7);


        }
    }



}

void drawAirport(float zoomLvl) {
    if (zoomLvl > 20) {


        setlinestyle(SOLID);
        setlinewidth(1);

        settextrotation(0);
        setfontsize(10);
        string airportName;

        for (unsigned j = 0; j < AirportPlots.size(); j++) {

            airportName = AirportPlots[j].tags[0].second;

            vector <Point> tmpVec = AirportPlots[j].coordinatesXYVec;
            setcolor(BLACK);

            unsigned i;

            for (i = 0; i < tmpVec.size() - 1; i++) {

                drawline(tmpVec[i].x, tmpVec[i].y, tmpVec[i + 1].x, tmpVec[i + 1].y);

            }
            setcolor(MAGENTA);
            float boundx = 1e-2;
            float boundy = 1e-2;

            if (zoomLvl > 100) {
                drawtext(tmpVec[0].x, tmpVec[0].y, airportName, boundx, boundy);
            }
        }

    }

}

void drawPOI(float zoomLvl) {
    float boundx = 0.00001;
    float boundy = 0.00001;
    float radius = 0.0000003;


    for (unsigned int i = 0; i < numOfPOI; i++) {
        bool flag = false;
        LatLon PointOfInterest = getPointOfInterestPosition(i);
        string POIName = getPointOfInterestName(i);
        string POIType = getPointOfInterestType(i);
        Point convertedPOI = conv_LatLon_to_XY(PointOfInterest);

        if (POIType == "fuel" || POIType == "hospital" || POIType == "pharmacy" ||
                POIType == "marketplace" || POIType == "school") {

            setcolor(RED);

            if (zoomLvl >= 100)
                flag = true;
        } else if (POIType == "restaurant" || POIType == "fastfood" || POIType == "cafe") {
            setcolor(DARKGREEN);

            if (zoomLvl >= 250)
                flag = true;
        } else if (POIType == "parking") {
            setcolor(GREEN);

            if (zoomLvl >= 100)
                flag = true;
        } else if (POIType == "bank" || POIType == "community_centre" || "bus_station"
                || POIType == "atm" || POIType == "post_office" || POIType == "library") {
            setcolor(BLACK);

            if (zoomLvl >= 150)
                flag = true;

        } else if (POIType == "cinema" || POIType == "bar" || POIType == "pub"
                || POIType == "condo" || POIType == "place_of_worship") {
            setcolor(MEDIUMPURPLE);

            if (zoomLvl >= 200)
                flag = true;
        }

        if (flag) {

            if (zoomLvl >= 900) {
                radius = 0.0000002;
                boundx = 0.000003;
                boundy = 0.000003;
            } else {
                radius = 0.0000003;
                boundx = 0.000001;
                boundy = 0.000001;
            }

            drawarc(convertedPOI.x, convertedPOI.y, radius, 0, 360);
            setfontsize(10);
            setcolor(BLACK);

            drawtext(convertedPOI.x, convertedPOI.y, POIName, boundx, boundy);
        }


    }


}

void showHotels(float zoomLvl) {
    float boundx = 0.00001;
    float boundy = 0.00001;


    if (zoomLvl > 40) {

        for (unsigned i = 0; i < HotelPlots.size(); i++) {
            setcolor(MAGENTA);
            setlinestyle(SOLID);
            setlinewidth(2);
            LatLon hotelPos = HotelPlots[i].coordinates;

            Point hotelPosXY = conv_LatLon_to_XY(hotelPos);

            string hotelName = HotelPlots[i].hotelName;

            drawarc(hotelPosXY.x, hotelPosXY.y, 1e-6, 0, 360);
            setfontsize(10);

            setcolor(MEDIUMPURPLE);
            settextrotation(0);
            drawtext(hotelPosXY.x, hotelPosXY.y, hotelName, boundx, boundy);

        }
    }

}

void showStreetNames(float zoomLvl) {

    for (unsigned int i = 0; i < numOfStreets; i++) {
        if (getStreetName(i) == "<unknown>") {

        } else {
            vector <unsigned> thisStreet = streetIds_streetSegsVector[i].idVec;
            setcolor(BLACK);
            unsigned thisStreetSize = thisStreet.size();

            for (unsigned int j = 1; j < thisStreetSize; j++) {

                StreetSegmentInfo curSeg = streetSegmentInformationVec[thisStreet[j]];

                unsigned intersection1 = curSeg.from;
                unsigned intersection2 = curSeg.to;

                LatLon tmpPosInter1 = intersectionPositionVec[intersection1];
                LatLon tmpPosInter2 = intersectionPositionVec[intersection2];

                Point interPos1 = conv_LatLon_to_XY(tmpPosInter1);
                Point interPos2 = conv_LatLon_to_XY(tmpPosInter2);

                if (interPos2.x - interPos1.x == 0) {

                    settextrotation(90);

                    drawtext(interPos1.x, (interPos1.y + interPos2.y) / 2,
                            getStreetName(i), abs(interPos1.x - interPos2.x),
                            abs(interPos1.y - interPos2.y));
                } else {

                    double gradient = (interPos2.y - interPos1.y) / (interPos2.x - interPos1.x);
                    double theta = atan(gradient)*(180 / M_PI);

                    settextrotation(theta);

                    drawtext((interPos1.x + interPos2.x) / 2,
                            (interPos1.y + interPos2.y) / 2, getStreetName(i),
                            abs(interPos1.x - interPos2.x),
                            abs(interPos1.y - interPos2.y));
                }
            }
        }
    }


}

void showDirections(const std::vector<unsigned>& path, const std::vector<unsigned>& interIDsPath) {
    cout << "Every direction that appears across one line of the screen represents the direction "
            "that you have to travel in to get from the current intersection to get to the next one.\n\n";

    double basicallyZeroComparison = 0.000001;
    //If path is not empty, process it 
    if (path.empty() == false) {
        //Loop through all street segments making up this path
        for (unsigned int i = 0; i < interIDsPath.size() - 1; i++) {
            string direction;
            bool differentStreets = false;
            unsigned seg_id = path[i];
            StreetSegmentInfo curSeg = streetSegmentInformationVec[seg_id];
            unsigned intersection1 = interIDsPath[i];
            unsigned intersection2 = interIDsPath[i + 1];

            LatLon tmpPosInter1 = intersectionPositionVec[intersection1];
            LatLon tmpPosInter2 = intersectionPositionVec[intersection2];

            Point interPos1 = conv_LatLon_to_XY(tmpPosInter1);
            Point interPos2 = conv_LatLon_to_XY(tmpPosInter2);



            // Check if the 2nd segment belongs to another road
            // indexing runs 1 less than the length
            if ((i + 1) < path.size()) {
                unsigned seg_id2 = path[i + 1];

                if (streetSegmentInformationVec[seg_id].streetID != streetSegmentInformationVec[seg_id2].streetID) {
                    //Means the seg are from different streets, set the flag
                    differentStreets = true;
                    //Have to make a turn from one street to the other
                }

                if (differentStreets == true) {
                    //StreetSegmentInfo nexSeg = streetSegmentInformationVec[seg_id2];
                    unsigned intersection3 = interIDsPath[i + 1];
                    unsigned intersection4 = interIDsPath[i + 2];

                    LatLon tmpPosInter3 = intersectionPositionVec[intersection3];
                    LatLon tmpPosInter4 = intersectionPositionVec[intersection4];

                    Point interPos3 = conv_LatLon_to_XY(tmpPosInter3);
                    Point interPos4 = conv_LatLon_to_XY(tmpPosInter4);

                    if (abs(interPos4.x - interPos3.x) <= basicallyZeroComparison) {

                        //Vertical line, since both x coordinates are the same
                        //Figure out whether vertical line is upwards (to is at higher)
                        //location than from or vice versa
                        if (interPos4.y > interPos3.y) {
                            direction = "North";
                        } else {
                            direction = "South";
                        }

                    }//Horizontal line, since both y coordinates are the same 
                    else if (abs(interPos4.y - interPos3.y) <= basicallyZeroComparison) {
                        if (interPos4.x > interPos3.x) {
                            direction = "East";

                        } else {
                            direction = "West";
                        }

                    }//Something in between, both intersections are at an angle to each other
                    else {

                        double gradient = ((interPos4.y - interPos3.y) / (interPos4.x - interPos3.x));
                        double theta = atan(gradient)*(180 / M_PI);
                        if (interPos4.y > interPos3.y || interPos4.x > interPos3.x) {

                        } else {
                            theta = (theta)*-1;

                        }


                        if ((theta >= 0 && theta < 45) || (theta > -45 && theta <= 0)) {
                            direction = "East";
                        } else if ((theta >= 45 && theta < 90) || (theta >= -315 && theta < -270)) {
                            direction = "Northeast";
                        } else if ((theta >= 90 && theta < 135) || (theta >= -270 && theta < -225)) {
                            direction = "North";
                        } else if ((theta >= 135 && theta < 180) || (theta >= -225 && theta < -180)) {
                            direction = "Northwest";
                        } else if ((theta >= 180 && theta < 225) || (theta >= -180 && theta < -135)) {
                            direction = "West";
                        } else if ((theta >= 225 && theta < 270) || (theta >= -135 && theta < -90)) {
                            direction = "Southwest";

                        } else if ((theta <= 270 && theta < 315) || (theta >= -90 && theta < -45)) {
                            direction = "South";
                        } else {
                            direction = "Southeast";
                        }

                    }
                    cout << "Direction for next street is " << direction << "\n";

                } else {
                    cout << "Continue to ";
                    //Do nothing
                }

            }

            //Now process current segment 
            if (abs(interPos2.x - interPos1.x) <= basicallyZeroComparison) {
                //                cout << "Position 2 x is " << interPos2.x << " y is " << interPos2.y << "\n";
                //                cout << "Position 1 x is " << interPos1.x << " y is " << interPos1.y << "\n";
                //                //     cout<<(interPos2.x-interPos1.x)<<" Reulst of subtraction is -< "<<"\n\n";
                //                cout << "Vertical line found -> result of x2-x1 is " << (interPos2.x - interPos1.x) << "\n";

                //Vertical line, since both x coordinates are the same
                //Figure out whether vertical line is upwards (to is at higher)
                //location than from or vice versa
                if (interPos2.y > interPos1.y) {
                    cout << "Head north on " << getStreetName(curSeg.streetID) << "\n";
                    if (differentStreets == true) {
                        unsigned streetIDInfo = streetSegmentInformationVec[path[i + 1]].streetID;
                        string streetName = getStreetName(streetIDInfo);
                        if (direction == "North") {
                            cout << "Then keep moving straight on to " << streetName << "\n";
                        } else if (direction == "West") {
                            cout << "Then turn left on to " << streetName << "\n";
                        } else if (direction == "East") {
                            cout << "Then turn right on to " << streetName << "\n";
                        } else if (direction == "Northeast") {
                            cout << "Then make a slight right turn on to " << streetName << "\n";
                        } else if (direction == "Northwest") {
                            cout << "Then make a slight left turn on to " << streetName << "\n";
                        }
                    }
                } else {
                    cout << "Head south on " << getStreetName(curSeg.streetID) << "\n";
                    if (differentStreets == true) {
                        unsigned streetIDInfo = streetSegmentInformationVec[path[i + 1]].streetID;
                        string streetName = getStreetName(streetIDInfo);
                        if (direction == "South") {
                            cout << "Then keep moving straight on to " << streetName << "\n";
                        } else if (direction == "West") {
                            cout << "Then turn right on to " << streetName << "\n";
                        } else if (direction == "East") {
                            cout << "Then turn left on to " << streetName << "\n";
                        } else if (direction == "Southeast") {
                            cout << "Then make a slight left turn on to " << streetName << "\n";
                        } else if (direction == "Southwest") {
                            cout << "Then make a slight right turn on to " << streetName << "\n";
                        }
                    }

                }

            }//Horizontal line, since both y coordinates are the same 
            else if (abs(interPos2.y - interPos1.y) <= basicallyZeroComparison) {

                if (interPos2.x > interPos1.x) {
                    cout << "Head east on " << getStreetName(curSeg.streetID) << "\n";
                    if (differentStreets == true) {
                        unsigned streetIDInfo = streetSegmentInformationVec[path[i + 1]].streetID;
                        string streetName = getStreetName(streetIDInfo);
                        if (direction == "East") {
                            cout << "Then keep moving straight on to " << streetName << "\n";
                        } else if (direction == "North") {
                            cout << "Then turn left on to " << streetName << "\n";
                        } else if (direction == "South") {
                            cout << "Then turn right on to " << streetName << "\n";
                        } else if (direction == "Northeast") {
                            cout << "Then make a slight left turn on to " << streetName << "\n";
                        } else if (direction == "Southeast") {
                            cout << "Then make a slight right turn on to " << streetName << "\n";
                        }
                    }
                } else {
                    cout << "Head west on " << getStreetName(curSeg.streetID) << "\n";
                    if (differentStreets == true) {
                        unsigned streetIDInfo = streetSegmentInformationVec[path[i + 1]].streetID;
                        string streetName = getStreetName(streetIDInfo);
                        if (direction == "West") {
                            cout << "Then keep moving straight on to " << streetName << "\n";
                        } else if (direction == "South") {
                            cout << "Then turn left on to " << streetName << "\n";
                        } else if (direction == "North") {
                            cout << "Then turn right on to " << streetName << "\n";
                        } else if (direction == "Northwest") {
                            cout << "Then make a slight right turn on to " << streetName << "\n";
                        } else if (direction == "Southwest") {
                            cout << "Then make a slight left turn on to " << streetName << "\n";
                        }
                    }
                }

            }//Something in between, both intersections are at an angle to each other
            else {

                double gradient = ((interPos2.y - interPos1.y) / (interPos2.x - interPos1.x));
                double theta = atan(gradient)*(180 / M_PI);
                if (interPos2.y > interPos1.y || interPos2.x > interPos1.x) {

                } else {
                    theta = (theta)*-1;

                }

                if ((theta >= 0 && theta <= 90) || (theta >= -360 && theta <= -270)) {
                    cout << "Head northeast on " << getStreetName(curSeg.streetID) << "\n";
                    if (differentStreets == true) {
                        unsigned streetIDInfo = streetSegmentInformationVec[path[i + 1]].streetID;
                        string streetName = getStreetName(streetIDInfo);
                        if (direction == "East") {
                            cout << "Then keep moving straight on to " << streetName << "\n";
                        } else if (direction == "North") {
                            cout << "Then turn left on to " << streetName << "\n";
                        } else if (direction == "South") {
                            cout << "Then turn right on to " << streetName << "\n";
                        } else if (direction == "Northeast") {
                            cout << "Then make a slight right turn on to " << streetName << "\n";
                        } else if (direction == "Northwest") {
                            cout << "Then make a slight left turn on to " << streetName << "\n";
                        }
                    }
                } else if ((theta >= 90 && theta <= 180) || (theta >= -270 && theta <= -180)) {
                    cout << "Head northwest on " << getStreetName(curSeg.streetID) << "\n";
                    if (differentStreets == true) {
                        unsigned streetIDInfo = streetSegmentInformationVec[path[i + 1]].streetID;
                        string streetName = getStreetName(streetIDInfo);
                        if (direction == "West") {
                            cout << "Then keep moving straight on to " << streetName << "\n";
                        } else if (direction == "South") {
                            cout << "Then turn left on to " << streetName << "\n";
                        } else if (direction == "North") {
                            cout << "Then turn right on to " << streetName << "\n";
                        } else if (direction == "Northwest") {
                            cout << "Then make a slight right turn on to " << streetName << "\n";
                        } else if (direction == "Southwest") {
                            cout << "Then make a slight left turn on to " << streetName << "\n";
                        }
                    }
                } else if ((theta <= 180 && theta <= 270) || (theta >= -180 && theta <= -90)) {
                    cout << "Head southwest on " << getStreetName(curSeg.streetID) << "\n";
                    if (differentStreets == true) {
                        unsigned streetIDInfo = streetSegmentInformationVec[path[i + 1]].streetID;
                        string streetName = getStreetName(streetIDInfo);
                        if (direction == "West") {
                            cout << "Then keep moving straight on to " << streetName << "\n";
                        } else if (direction == "South") {
                            cout << "Then turn left on to " << streetName << "\n";
                        } else if (direction == "North") {
                            cout << "Then turn right on to " << streetName << "\n";
                        } else if (direction == "Northwest") {
                            cout << "Then make a slight right turn on to " << streetName << "\n";
                        } else if (direction == "Southwest") {
                            cout << "Then make a slight left turn on to " << streetName << "\n";
                        }
                    }
                } else {
                    cout << "Head southeast on " << getStreetName(curSeg.streetID) << "\n";
                    if (differentStreets == true) {
                        unsigned streetIDInfo = streetSegmentInformationVec[path[i + 1]].streetID;
                        string streetName = getStreetName(streetIDInfo);
                        if (direction == "East") {
                            cout << "Then keep moving straight on to " << streetName << "\n";
                        } else if (direction == "North") {
                            cout << "Then turn left on to " << streetName << "\n";
                        } else if (direction == "South") {
                            cout << "Then turn right on to " << streetName << "\n";
                        } else if (direction == "Northeast") {
                            cout << "Then make a slight right turn on to " << streetName << "\n";
                        } else if (direction == "Northwest") {
                            cout << "Then make a slight left turn on to " << streetName << "\n";
                        }
                    }
                }

            }
            differentStreets = false;
            direction = "";

        }




    }

}

void drawscreen(void) {


    //float radius;


    set_draw_mode(DRAW_NORMAL); // Should set this if your program does any XOR drawing in callbacks.
    clearscreen(); /* Should precede drawing for all drawscreens */

    setfontsize(10);
    setlinestyle(SOLID);

    // Getting the zoom levels 
    t_bound_box curBox = get_visible_world();
    float zoomLev = initial_coords.get_width() / curBox.get_width();


    if (mapName == "/cad2/ece297s/public/maps/london_england.streets.bin") {


        drawFeatures(zoomLev);
        drawParks(zoomLev);

        drawRivers(zoomLev);
        drawBuildings(zoomLev);
        showHotels(zoomLev);

        drawPOI(zoomLev);
        drawStreets();
        showStreetNames(zoomLev);


    } else {

        drawFeatures(zoomLev);
        drawGolfCourses(zoomLev);
        drawRunWay(zoomLev);

        drawParks(zoomLev);
        drawRivers(zoomLev);
        drawBuildings(zoomLev);

        drawStreets();
        drawAirport(zoomLev);
        drawPOI(zoomLev);

        showHotels(zoomLev);
        showStreetNames(zoomLev);
    }

    // redrawing highlighted intersections of the streets
    if (findPressed == true && zoomLev > 50) {

        for (unsigned i = 0; i < highlightInterPts.size(); i++) {
            setlinestyle(SOLID);
            setcolor(YELLOW);
            setlinewidth(2);
            fillarc(highlightInterPts[i].x, highlightInterPts[i].y, 1e-6, 0, 360);
        }
    }

    findPressed = false;
    highlightInterPts.clear();


    if (showInters_Path == true) {
        setlinewidth(2);
        setcolor(RED);
        setlinestyle(SOLID);

        drawarc(interPosXY.x, interPosXY.y, 1e-6, 0, 360);

        //green is for intersection near POI
        setlinewidth(2);
        setcolor(GREEN);
        setlinestyle(SOLID);

        drawarc(interPosXY2.x, interPosXY2.y, 1e-6, 0, 360);

        drawPath(idx1, idx2);


    }




    if (showPOIPath == true) {
        //red is for starting intersection

        setlinewidth(2);
        setcolor(RED);
        setlinestyle(SOLID);

        drawarc(interPosXY.x, interPosXY.y, 1e-6, 0, 360);

        //green is for intersection near POI
        setlinewidth(2);
        setcolor(GREEN);
        setlinestyle(SOLID);

        drawarc(interPosXY2.x, interPosXY2.y, 1e-6, 0, 360);

        drawPath(idx1, idx2);
    }




    if (clearStartInter_InterClix == false) {
        setlinewidth(6);


        setlinestyle(SOLID);
        setcolor(RED);

        //redraw start intersection
        if (zoomLev <= 4) {
            drawarc(interPosXY.x, interPosXY.y, 1e-4, 0, 360);
            setcolor(GREEN);
            drawarc(interPosXY2.x, interPosXY2.y, 1e-4, 0, 360);

        } else if (zoomLev > 4 && zoomLev <= 35) {
            //More zoom hence, make radius smaller
            drawarc(interPosXY.x, interPosXY.y, 1e-5, 0, 360);
            setcolor(GREEN);
            drawarc(interPosXY2.x, interPosXY2.y, 1e-5, 0, 360);

        } else if (zoomLev > 35) {

            drawarc(interPosXY.x, interPosXY.y, 1e-6, 0, 360);
            setcolor(GREEN);
            drawarc(interPosXY2.x, interPosXY2.y, 1e-6, 0, 360);

        }



    }

    if (resetDraw == false && numOfClicks == 2) {
        drawPath(idx1, idx2);


    }

    if (showFindPath == true) {//when user entered 2 intersection ids, make that stick
        drawPath(idx1, idx2);
    }







    //my friends segments for failing toronto case in start

    //    drawPath(getStreetSegmentInfo(62264).from,getStreetSegmentInfo(62264).to);
    //    drawPath(getStreetSegmentInfo(151226).from,getStreetSegmentInfo(151226).to);
    //    
    //    drawPath(getStreetSegmentInfo(151227).from,getStreetSegmentInfo(151227).to);
    //    
    //    drawPath(getStreetSegmentInfo(62269).from,getStreetSegmentInfo(62269).to);
    //    drawPath(getStreetSegmentInfo(62278).from,getStreetSegmentInfo(62278).to);
    //    drawPath(getStreetSegmentInfo(83734).from,getStreetSegmentInfo(83734).to);
    //    drawPath(getStreetSegmentInfo(83735).from,getStreetSegmentInfo(83735).to);
    //    drawPath(getStreetSegmentInfo(83736).from,getStreetSegmentInfo(83736).to);
    //    drawPath(getStreetSegmentInfo(61700).from,getStreetSegmentInfo(61700).to);
    //    drawPath(getStreetSegmentInfo(61702).from,getStreetSegmentInfo(61702).to);

    //--------------------------------------------------------------------------------

}

//for finding closest hotel

unsigned find_closest_Hotel(LatLon my_position) {

    LatLon hotel0Pos = HotelPlots[0].coordinates;

    //Compute distance between myPosition and PointOfInterest(0)
    double distance = find_distance_squared_between_two_points(my_position,
            hotel0Pos);

    //If hotel and current location are the same, return ID 0
    if (distance == 0) {
        return 0;
    }

    unsigned nearestHotelId = 0;
    //Compute distance between myPosition and all hotels in the 
    //city 

    for (unsigned i = 1; i < HotelPlots.size(); i++) {
        LatLon hotelPos = HotelPlots[i].coordinates;

        double intermediate = find_distance_squared_between_two_points(my_position,
                hotelPos);
        if (intermediate == 0) {
            return i;
        }//If calculated distance in this iteration is less than current value
            //of distance, update the distance value and the ID value 
        else if (intermediate < distance) {
            distance = intermediate;

            nearestHotelId = i;
        }
    }
    return nearestHotelId;
}

//Given the stem 'stem_text' perform auto completion. 
//It returns an array of strings that are potential completions
//
//Note:
// 'start' and 'end' denote the location of 'stem_text' in the global
// 'rl_line_buffer' variable which contains the users current input line.
// If you need more context information to determine how to complete 'stem_text'
// you could look at 'rl_line_buffer'.

char** command_completion(const char* stem_text, int start, int end) {
    char ** matches = NULL;

    //Only generate completions if stem_text' 
    //is not the first thing in the buffer
    matches = rl_completion_matches(stem_text, street_name_generator);


    return matches;
}

//Called repeatedly for a given 'stem_text'. Each time it returns a potential
//match.  When there are no more matches it returns NULL.
//
//The 'state' variable is zero the first time it is called with a given
//'stem_text', and positive afterwards.

char* street_name_generator(const char* stem_text, int state) {
    //Static here means a variable's value persists across function invocations
    static int count;

    if (state == 0) {
        //We initialize the count the first time we are called
        //with this stem_text
        count = -1;
    }

    int text_len = strlen(stem_text);

    //Search through intersection_names until we find a match
    while (count < (int) streetNames.size() - 1) {
        count++;
        if (strncmp(streetNames[count], stem_text, text_len) == 0) {
            //Must return a duplicate, Readline will handle
            //freeing this string itself.
            return strdup(streetNames[count]);
        }
    }

    //No more matches
    return NULL;
}

char** command_completionPOI(const char* stem_text, int start, int end) {
    char ** matches = NULL;

    //Only generate completions if stem_text' 
    //is not the first thing in the buffer
    matches = rl_completion_matches(stem_text, POI_name_generator);


    return matches;
}

//Called repeatedly for a given 'stem_text'. Each time it returns a potential
//match.  When there are no more matches it returns NULL.
//
//The 'state' variable is zero the first time it is called with a given
//'stem_text', and positive afterwards.

char* POI_name_generator(const char* stem_text, int state) {
    //Static here means a variable's value persists across function invocations
    static int count;

    if (state == 0) {
        //We initialize the count the first time we are called
        //with this stem_text
        count = -1;
    }

    int text_len = strlen(stem_text);

    //Search through intersection_names until we find a match
    while (count < (int) POINames.size() - 1) {
        count++;
        if (strncmp(POINames[count], stem_text, text_len) == 0) {
            //Must return a duplicate, Readline will handle
            //freeing this string itself.
            return strdup(POINames[count]);
        }
    }

    //No more matches
    return NULL;
}




//FIXING THIS

void act_on_FindPath_buttonPress(void (*drawscreen_ptr) (void)) {

    string streetName1, streetName2;
    string streetName3, streetName4;
    string POIName;

    //Use tab for auto completion
    rl_bind_key('\t', rl_complete);
    //Use our function for auto-complete
    rl_attempted_completion_function = command_completion;
    //Tell readline to handle double and single quotes for us
    rl_completer_quote_characters = strdup("\"\'");

    cout << " Enter I for path between two Intersections or P for a path "
            "between a point of interest and an intersection: ";
    string userChoice;
    getline(cin, userChoice);

    if (userChoice == "I") {
        char* firstName; //Buffer of line entered by user

        firstName = readline("Enter street name (Begin with \" and conclude with \")  "); //Prompt the user for input
        if (strcmp(firstName, "") != 0) { //Only save non-empty commands
            add_history(firstName);
        }

        //Currently we just print out the input line
        cout << firstName << endl;

        //readline generates a new buffer every time, 
        //so we need to free the current one after we've finished
        string temp = firstName;

        if (temp.at(temp.length() - 1) == '"') {
            streetName1 = temp.substr(1, temp.length() - 2);
        } else if (temp.at(temp.length() - 2) == '"') {
            streetName1 = temp.substr(1, temp.length() - 3);
        } else {
            streetName1 = temp.substr(1, temp.length() - 1);
        }
        free(firstName);
        firstName = NULL; //Mark it null to show we freed it

        //If the buffer wasn't freed in the main loop we need to free it now
        // Note: if buf is NULL free does nothing
        free(firstName);

        cout << "First name is" << streetName1 << endl;

        char* secondName; //Buffer of line entered by user

        secondName = readline("Enter street name (Begin with \") and conclude with \")  "); //Prompt the user for input
        if (strcmp(secondName, "") != 0) { //Only save non-empty commands
            add_history(secondName);
        }

        //Currently we just print out the input line
        cout << secondName << endl;

        string secondExtract = secondName;

        //readline generates a new buffer every time, 
        //so we need to free the current one after we've finished
        if (secondExtract.at(secondExtract.length() - 1) == '"') {
            streetName2 = secondExtract.substr(1, secondExtract.length() - 2);
        } else if (secondExtract.at(secondExtract.length() - 2) == '"') {
            streetName2 = secondExtract.substr(1, secondExtract.length() - 3);
        } else {
            streetName2 = secondExtract.substr(1, secondExtract.length() - 1);
        }
        free(secondName);
        secondName = NULL; //Mark it null to show we freed it


        //If the buffer wasn't freed in the main loop we need to free it now
        // Note: if buf is NULL free does nothing
        free(secondName);

        cout << "Second name is " << streetName2 << endl;

        auto it1 = Street_name_to_id_map.find(streetName1);
        auto it2 = Street_name_to_id_map.find(streetName2);

        bool flag = false;

        if (it1 == Street_name_to_id_map.end()) {
            cout << "\nStreet Name 1 doesnot exist\n";
            flag = true;
        }

        if (it2 == Street_name_to_id_map.end()) {
            cout << "\nStreet Name 2 doesnot exist\n";
            flag = true;

        }

        if (flag == true) {
            cout << "Operation of highlighting the intersections wouldnot happen\n";
            return;
        }

        firstName = readline("Enter street name (Begin with \") and conclude with \")  "); //Prompt the user for input
        if (strcmp(firstName, "") != 0) { //Only save non-empty commands
            add_history(firstName);
        }

        //Currently we just print out the input line
        cout << firstName << endl;

        secondExtract = firstName;

        //readline generates a new buffer every time, 
        //so we need to free the current one after we've finished
        if (secondExtract.at(secondExtract.length() - 1) == '"') {
            streetName3 = secondExtract.substr(1, secondExtract.length() - 2);
        } else if (secondExtract.at(secondExtract.length() - 2) == '"') {
            streetName3 = secondExtract.substr(1, secondExtract.length() - 3);
        } else {
            streetName3 = secondExtract.substr(1, secondExtract.length() - 1);
        }
        free(firstName);
        firstName = NULL; //Mark it null to show we freed it


        //If the buffer wasn't freed in the main loop we need to free it now
        // Note: if buf is NULL free does nothing
        free(firstName);

        //   secondName; //Buffer of line entered by user //had no effect

        secondName = readline("Enter street name (Begin with \") and conclude with \")  "); //Prompt the user for input
        if (strcmp(secondName, "") != 0) { //Only save non-empty commands
            add_history(secondName);
        }

        //Currently we just print out the input line
        cout << secondName << endl;

        secondExtract = secondName;

        //readline generates a new buffer every time, 
        //so we need to free the current one after we've finished
        if (secondExtract.at(secondExtract.length() - 1) == '"') {
            streetName4 = secondExtract.substr(1, secondExtract.length() - 2);
        } else if (secondExtract.at(secondExtract.length() - 2) == '"') {
            streetName4 = secondExtract.substr(1, secondExtract.length() - 3);
        } else {
            streetName4 = secondExtract.substr(1, secondExtract.length() - 1);
        }
        free(secondName);
        secondName = NULL; //Mark it null to show we freed it


        //If the buffer wasn't freed in the main loop we need to free it now
        // Note: if buf is NULL free does nothing
        free(secondName);

        it1 = Street_name_to_id_map.find(streetName3);
        it2 = Street_name_to_id_map.find(streetName4);

        flag = false;

        if (it1 == Street_name_to_id_map.end()) {
            cout << "\nStreet Name 3 doesnot exist\n";
            flag = true;
        }

        if (it2 == Street_name_to_id_map.end()) {
            cout << "\nStreet Name 4 doesnot exist\n";
            flag = true;

        }

        if (flag == true) {
            cout << "Operation of highlighting the intersections wouldnot happen\n";
            return;
        }


    } else if (userChoice == "P") {
        char* firstName; //Buffer of line entered by user

        firstName = readline("Enter street name (Begin with \" and conclude with \")  "); //Prompt the user for input
        if (strcmp(firstName, "") != 0) { //Only save non-empty commands
            add_history(firstName);
        }

        //Currently we just print out the input line
        cout << firstName << endl;

        //readline generates a new buffer every time, 
        //so we need to free the current one after we've finished
        string temp = firstName;

        if (temp.at(temp.length() - 1) == '"') {
            streetName1 = temp.substr(1, temp.length() - 2);
        } else if (temp.at(temp.length() - 2) == '"') {
            streetName1 = temp.substr(1, temp.length() - 3);
        } else {
            streetName1 = temp.substr(1, temp.length() - 1);
        }
        free(firstName);
        firstName = NULL; //Mark it null to show we freed it

        //If the buffer wasn't freed in the main loop we need to free it now
        // Note: if buf is NULL free does nothing
        free(firstName);

        cout << "First name is" << streetName1 << endl;

        char* secondName; //Buffer of line entered by user

        secondName = readline("Enter street name (Begin with \") and conclude with \")  "); //Prompt the user for input
        if (strcmp(secondName, "") != 0) { //Only save non-empty commands
            add_history(secondName);
        }

        //Currently we just print out the input line
        cout << secondName << endl;

        string secondExtract = secondName;

        //readline generates a new buffer every time, 
        //so we need to free the current one after we've finished
        if (secondExtract.at(secondExtract.length() - 1) == '"') {
            streetName2 = secondExtract.substr(1, secondExtract.length() - 2);
        } else if (secondExtract.at(secondExtract.length() - 2) == '"') {
            streetName2 = secondExtract.substr(1, secondExtract.length() - 3);
        } else {
            streetName2 = secondExtract.substr(1, secondExtract.length() - 1);
        }
        free(secondName);
        secondName = NULL; //Mark it null to show we freed it


        //If the buffer wasn't freed in the main loop we need to free it now
        // Note: if buf is NULL free does nothing
        free(secondName);

        cout << "Second name is " << streetName2 << endl;

        auto it1 = Street_name_to_id_map.find(streetName1);
        auto it2 = Street_name_to_id_map.find(streetName2);

        bool flag = false;

        if (it1 == Street_name_to_id_map.end()) {
            cout << "\nStreet Name 1 doesnot exist\n";
            flag = true;
        }

        if (it2 == Street_name_to_id_map.end()) {
            cout << "\nStreet Name 2 doesnot exist\n";
            flag = true;

        }

        if (flag == true) {
            cout << "Operation of highlighting the intersections wouldnot happen\n";
            return;
        }

        //Use tab for auto completion
        rl_bind_key('\t', rl_complete);
        //Use our function for auto-complete
        rl_attempted_completion_function = command_completionPOI;
        //Tell readline to handle double and single quotes for us
        rl_completer_quote_characters = strdup("\"\'");

        firstName = readline("Enter POI name (Begin with \" and conclude with \")  "); //Prompt the user for input
        if (strcmp(firstName, "") != 0) { //Only save non-empty commands
            add_history(firstName);
        }

        //Currently we just print out the input line
        cout << firstName << endl;

        //readline generates a new buffer every time, 
        //so we need to free the current one after we've finished
        temp = firstName;

        if (temp.at(temp.length() - 1) == '"') {
            POIName = temp.substr(1, temp.length() - 2);
        } else if (temp.at(temp.length() - 2) == '"') {
            POIName = temp.substr(1, temp.length() - 3);
        } else {
            POIName = temp.substr(1, temp.length() - 1);
        }
        free(firstName);
        firstName = NULL; //Mark it null to show we freed it

        //If the buffer wasn't freed in the main loop we need to free it now
        // Note: if buf is NULL free does nothing
        free(firstName);

        cout << "POI name is" << POIName << endl;



    } else {
        cout << "Invalid Input, exiting";
        return;
    }

    if (userChoice == "I") {
        vector <unsigned> interIdsVec1 = find_intersection_ids_from_street_names(streetName1, streetName2);
        vector <unsigned> interIdsVec2 = find_intersection_ids_from_street_names(streetName3, streetName4);

        //call show path with the two intersection vectors

        if (interIdsVec1.size() != 0 && interIdsVec2.size() != 0) {
            showInters_Path = true;




            drawPath(interIdsVec1[0], interIdsVec2[0]);

            LatLon inter1, inter2;
            idx1 = interIdsVec1[0];
            idx2 = interIdsVec2[0];

            inter1 = getIntersectionPosition(idx1);

            inter2 = getIntersectionPosition(idx2);


            Point inter1XY, inter2XY;

            inter1XY = conv_LatLon_to_XY(inter1);

            inter2XY = conv_LatLon_to_XY(inter2);

            //settting global points to redraw the start and end in draw screen
            interPosXY = inter1XY;

            interPosXY2 = inter2XY;



            //red is for starting intersection

            setlinewidth(2);
            setcolor(RED);
            setlinestyle(SOLID);

            drawarc(inter1XY.x, inter1XY.y, 1e-6, 0, 360);

            //green is for intersection near POI
            setlinewidth(2);
            setcolor(GREEN);
            setlinestyle(SOLID);

            drawarc(inter2XY.x, inter2XY.y, 1e-6, 0, 360);








        } else {
            cout << "No intersections were found of the entered streets\n";
        }

    } else if (userChoice == "P") {
        //call show Path
        vector <unsigned> interIdsVec1 = find_intersection_ids_from_street_names(streetName1, streetName2);

        if (interIdsVec1.size() != 0) {

            LatLon interPos = getIntersectionPosition(interIdsVec1[0]);

            unsigned id = find_closest_point_of_interest_by_name(interPos, POIName);

            unsigned POIIntersection = find_closest_intersection(getPointOfInterestPosition(id));

            idx1 = interIdsVec1[0];
            idx2 = POIIntersection;


            showPOIPath = true;
            drawPath(interIdsVec1[0], POIIntersection);

            LatLon inter1, inter2;
            inter1 = getIntersectionPosition(idx1);
            inter2 = getIntersectionPosition(idx2);


            Point inter1XY, inter2XY;
            inter1XY = conv_LatLon_to_XY(inter1);
            inter2XY = conv_LatLon_to_XY(inter2);

            //settting global points to redraw the start and end in draw screen
            interPosXY = inter1XY;
            interPosXY2 = inter2XY;



            //red is for starting intersection

            setlinewidth(2);
            setcolor(RED);
            setlinestyle(SOLID);

            drawarc(inter1XY.x, inter1XY.y, 1e-6, 0, 360);

            //green is for intersection near POI
            setlinewidth(2);
            setcolor(GREEN);
            setlinestyle(SOLID);

            drawarc(inter2XY.x, inter2XY.y, 1e-6, 0, 360);
            showPOIPath = true;


        } else {
            cout << "no intersection of entered street name was found\n";
        }

    }
    // drawscreen_ptr();

}

void act_on_new_button_func(void (*drawscreen_ptr) (void)) {

    cout << "Enter first street name: ";
    string streetName1, streetName2;
    getline(cin, streetName1);

    cout << "Enter second street name: ";
    getline(cin, streetName2);

    auto it1 = Street_name_to_id_map.find(streetName1);
    auto it2 = Street_name_to_id_map.find(streetName2);

    bool flag = false;

    if (it1 == Street_name_to_id_map.end()) {
        cout << "\nStreet Name 1 doesnot exist\n";
        flag = true;

    }
    if (it2 == Street_name_to_id_map.end()) {
        cout << "\nStreet Name 2 doesnot exist\n";
        flag = true;

    }
    if (flag == true) {
        cout << "Operation of highlighting the intersections wouldn't happen\n";
        return;
    }


    vector <unsigned> interIdsVec = find_intersection_ids_from_street_names(streetName1, streetName2);


    if (interIdsVec.size() != 0) {

        findPressed = true;

        for (unsigned i = 0; i < interIdsVec.size(); i++) {

            LatLon curInterPos = getIntersectionPosition(interIdsVec[i]);
            Point curInterXY = conv_LatLon_to_XY(curInterPos);

            highlightInterPts.push_back(curInterXY);


            //getting nearest POI from the intersection clicked
            unsigned closestPOI = find_closest_point_of_interest(curInterPos);
            string POIname = getPointOfInterestName(closestPOI);

            setlinewidth(2);
            setcolor(YELLOW);
            setlinestyle(DASHED);

            fillarc(curInterXY.x, curInterXY.y, 1e-6, 0, 360);


            //showing intersection information:
            cout << "\nIntersection Name: " << getIntersectionName(interIdsVec[i]) << endl;
            cout << "Nearest Point of Interest to this intersection: " << POIname << endl;



        }
        cout << endl;

    } else {
        cout << "No intersections were found of the entered streets\n";
    }


    drawscreen_ptr();

}

void act_on_Search_Hotel_buttonPress(void (*drawscreen_ptr) (void)) {

    cout << "\nEnter Hotel Name: ";
    string hotelName;
    getline(cin, hotelName);

    unsigned hotel_id = hotelNameToIdMap.at(hotelName);

    cout << "\nHotel Information:\n";
    vector< pair<string, string> > tagVec = HotelPlots[hotel_id].tags;

    for (unsigned i = 0; i < tagVec.size(); i++) {
        cout << tagVec[i].first << ": " << tagVec[i].second << endl;
    }

    cout << "------------------------------------------------\n";
    cout << endl;

}

void act_on_reset_clicks(void (*drawscreen_ptr) (void)) {

    numOfClicks = 0;

    //    cout << "after resetting clix: " << numOfClicks << endl;

    resetDraw = true;

    clearStartInter_InterClix = true;

    clearEndInter_InterClix = true;

    showPOIPath = false;
    showInters_Path = false;

    //cout << "redraw after reset clix: " << resetDraw << endl;

    showFindPath = false;
    drawscreen_ptr();

}

void drawPath(unsigned id1, unsigned id2) {

    pathVec.clear();
    //cout << "calling find path in drawpath\n";
    pathVec = find_path_between_intersections(id1, id2);
    //cout << "returned path size; " << pathVec.size() << endl;

    //cout << "checked size\n";
    //     for (unsigned i = 0; i < pathVec.size(); i++) {
    //         cout << pathVec[i]<<endl;
    //     }

    if (pathVec.size() != 0) {
      //  cout << "going to drawPath\n";
        for (unsigned i = 0; i < pathVec.size(); i++) {


            vector <Point> Curved_points;

            //returns the segment ids

            for (unsigned i = 0; i < pathVec.size(); i++) {
                //Point XY = conv
                //StreetSegmentInfo yo = getStreetSegmentInfo(pathVec[i]);

                unsigned seg_id = pathVec[i];
                // Grabbed 1 segment from the path
                StreetSegmentInfo yo = getStreetSegmentInfo(seg_id);

                vector <Point> Curved_points;

                LatLon a, b;


                a = getIntersectionPosition(yo.from);
                X = conv_LatLon_to_XY(a);

                b = getIntersectionPosition(yo.to);
                Y = conv_LatLon_to_XY(b);


                if (yo.curvePointCount == 0) {


                    //handling only straight lines
                    setlinewidth(3);
                    setlinestyle(SOLID);
                    setcolor(BLACK);

                    drawline(X.x, X.y, Y.x, Y.y);


                } else {

                    Curved_points.push_back(X);
                    for (unsigned i = 0; i < yo.curvePointCount; i++) {

                        LatLon CurPos = getStreetSegmentCurvePoint(seg_id, i);
                        Point cuvPosXY = conv_LatLon_to_XY(CurPos);
                        Curved_points.push_back(cuvPosXY);



                    }

                    Curved_points.push_back(Y);

                    setlinewidth(3);
                    setlinestyle(SOLID);
                    setcolor(BLACK);

                    for (unsigned i = 0; i < Curved_points.size() - 1; i++) {

                        drawline(Curved_points[i].x, Curved_points[i].y, Curved_points[i + 1].x, Curved_points[i + 1].y);

                    }


                }





            }

        }
    }


}

bool second_run = false;

void act_on_intersection_clicks(void (*drawscreen_ptr) (void)) {

    //unsigned idx1, idx2;

    unsigned max_inter_id = numOfIntersections;


    cout << "Enter the intersection 1: ";
    cin >>idx1;

    cout << "Enter the intersection 2: ";
    cin >>idx2;

    //storing the pos of start and ending intersections in global, in draw screen make the path stick!!!




    while (1) {


        if (idx1 <= max_inter_id && idx2 <= max_inter_id) {
            pathVec.clear();

            resetDraw = false;

            clearStartInter_InterClix = false;
            clearEndInter_InterClix = false;

            showFindPath = true;

            interPosXY = conv_LatLon_to_XY(getIntersectionPosition(idx1));
            interPosXY2 = conv_LatLon_to_XY(getIntersectionPosition(idx2));

            drawPath(idx1, idx2);




            break;

        } else {

            cin.clear();
            cout << "Out of range value \n Try again!" << endl;

            cout << " Enter the intersection 1: " << endl;

            cin >>idx1;

            cout << "Enter the intersection 2: " << endl;
            cin >>idx2;

        }



    }

}

void act_on_button_press(float x, float y, t_event_buttonPressed event) {

    numOfClicks++;

    // converting clicked position xy into latlon
    float latAverage = ((MaxLatLon_.lat * DEG_TO_RAD) + (minLatLon_.lat * DEG_TO_RAD)) / 2;


    if (numOfClicks == 1) {

        clickPos.lat = y / DEG_TO_RAD;
        clickPos.lon = x / (DEG_TO_RAD * cos(latAverage));

        closestInter = find_closest_intersection(clickPos);
        idx1 = closestInter;

        id1 = closestInter;
        cout << "Clicked intersection: " << id1 << endl;

        interPos = getIntersectionPosition(closestInter);
        interPosXY = conv_LatLon_to_XY(interPos);

        unsigned closestPOI = find_closest_point_of_interest(interPos);
        string POIname = getPointOfInterestName(closestPOI);


        cout << "\nIntersection Name: " << getIntersectionName(closestInter) << endl;
        cout << "Nearest Point of Interest to this intersection: " << POIname << endl;

        unsigned closestHotelId = find_closest_Hotel(interPos);
        string hotelName = HotelPlots[closestHotelId].hotelName;
        cout << "Closest Hotel to this intersection is: " << hotelName << endl;



    }


    setlinewidth(2);
    setcolor(RED);
    setlinestyle(DASHED);

    //red arc for starting node
    drawarc(interPosXY.x, interPosXY.y, 1e-6, 0, 360);
    //
    //
    //    //showing intersection information:
    //    cout << "\nIntersection Name: " << getIntersectionName(closestInter) << endl;
    //    cout << "Nearest Point of Interest to this intersection: " << POIname << endl;

    //    unsigned closestHotelId = find_closest_Hotel(interPos);
    //    string hotelName = HotelPlots[closestHotelId].hotelName;
    //    cout << "Closest Hotel to this intersection is: " << hotelName << endl;
    cout << endl;


    //black arc is for ending node

    if (numOfClicks == 2) {

        //numOfClicks = 0; //reset 
        resetDraw = false;

        LatLon clickPos2;
        clickPos2.lat = y / DEG_TO_RAD;
        clickPos2.lon = x / (DEG_TO_RAD * cos(latAverage));


        unsigned closestInter2 = find_closest_intersection(clickPos2);
        idx2 = closestInter2;

        LatLon interPos2 = getIntersectionPosition(closestInter2);
        //interPosXY = conv_LatLon_to_XY(interPos2);

        unsigned closestPOI = find_closest_point_of_interest(interPos2);
        string POIname = getPointOfInterestName(closestPOI);




        cout << "previously clicked intersection: " << closestInter << endl;
        cout << "clicked intersection: " << closestInter2 << endl;

        cout << "\nIntersection Name: " << getIntersectionName(closestInter2) << endl;
        cout << "Nearest Point of Interest to this intersection: " << POIname << endl;

        unsigned closestHotelId = find_closest_Hotel(interPos);
        string hotelName = HotelPlots[closestHotelId].hotelName;
        cout << "Closest Hotel to this intersection is: " << hotelName << endl;






        if (closestInter2 == closestInter) {
            cout << "Both intersections are same. You've already reached your destination\n";
        } else {
            cout << "Please Wait, finding the path\n";

            LatLon interPos2 = getIntersectionPosition(closestInter2);

            interPosXY2 = conv_LatLon_to_XY(interPos2);

            setlinewidth(2);
            setcolor(GREEN);
            setlinestyle(DASHED);


            fillarc(interPosXY2.x, interPosXY2.y, 1e-6, 0, 360);



            //drawing the path
            //it only has street segments
            //pathVec.clear();
            vector<unsigned> interIDs;
            //pathVec = find_path_between_intersections_for_showing_directions(closestInter, closestInter2, interIDs);


            drawPath(closestInter, closestInter2);



            //showDirections(pathVec, interIDs);
            cout << "You have reached your destination \n";
            clearStartInter_InterClix = false;

            clearEndInter_InterClix = false;
        }







    }


}

LatLon clickPos1, clickPos2;
bool clikonce = true;
bool clik2 = false;

void act_on_PathFinding_buttonPress(float x1, float y1, t_event_buttonPressed event) {
    cout << "enter path click finding\n";
    drawscreen();

    // converting clicked position xy into latlon

    float latAverage = ((MaxLatLon_.lat * DEG_TO_RAD) + (minLatLon_.lat * DEG_TO_RAD)) / 2;

    unsigned closestInter2;

    clickPos1.lat = y1 / DEG_TO_RAD;
    clickPos1.lon = x1 / (DEG_TO_RAD * cos(latAverage));

    unsigned closestInter1 = find_closest_intersection(clickPos1);


    unsigned id1 = closestInter1;
    cout << "clicked intersection: " << id1 << endl;

    LatLon interPos1 = getIntersectionPosition(closestInter1);
    Point interPosXY1 = conv_LatLon_to_XY(interPos1);

    LatLon interPos2 = getIntersectionPosition(closestInter2);
    Point interPosXY2 = conv_LatLon_to_XY(interPos2);


    cout << "click1: " << boolalpha << clikonce << endl;
    cout << "click2: " << boolalpha << clik2 << endl;


    if (clik2 == true) {

        clickPos2.lat = y1 / DEG_TO_RAD;
        clickPos2.lon = x1 / (DEG_TO_RAD * cos(latAverage));
        closestInter2 = find_closest_intersection(clickPos2);
        //        unsigned id2 = closestInter2;


        if (closestInter2 == closestInter1) {
            cout << "same interesection sel twice: won't run algo\n";
        } else {
            cout << "different intersections clicked, run algo\n";
            vector <unsigned> pathVec = find_path_between_intersections(closestInter1, closestInter2);

            for (unsigned i = 0; i < pathVec.size(); i++) {
                //Point XY = conv
                StreetSegmentInfo yo = getStreetSegmentInfo(pathVec[i]);
                LatLon a, b;
                a = getIntersectionPosition(yo.from);
                b = getIntersectionPosition(yo.to);
                Point X, Y;
                X = conv_LatLon_to_XY(a);
                Y = conv_LatLon_to_XY(b);

                if (yo.to == closestInter1 || yo.from == closestInter1) {
                    //start intersection draw in diff color
                    setcolor(RED);
                    setlinestyle(DASHED);
                    drawarc(Y.x, Y.y, 1e-6, 0, 360);
                }
                if (yo.from == closestInter2 || yo.to == closestInter2) {
                    //end intersection draw in diff color
                    setcolor(BLACK);
                    setlinestyle(DASHED);

                    drawarc(X.x, X.y, 1e-6, 0, 360);
                }

                unsigned cuvPts = yo.curvePointCount;
                unsigned stSegIndex = pathVec[i];
                vector <Point> drawVec;

                drawVec.push_back(interPosXY1);


                if (cuvPts > 0) {

                    for (unsigned i = 0; i < cuvPts; i++) {

                        LatLon CurPos = getStreetSegmentCurvePoint(stSegIndex, i);
                        Point cuvPosXY = conv_LatLon_to_XY(CurPos);
                        drawVec.push_back(cuvPosXY);
                    }
                    //LatLon

                    drawVec.push_back(interPosXY2);

                    for (unsigned i = 0; i < drawVec.size() - 1; i++) {
                        //setcolor(BLACK);
                        setlinestyle(SOLID);
                        //setlinewidth(1);
                        drawline(drawVec[i].x, drawVec[i].y, drawVec[i + 1].x, drawVec[i + 1].y);

                    }

                } else {

                    setlinewidth(1);
                    setlinestyle(SOLID);
                    setcolor(GREEN);
                    drawline(X.x, X.y, Y.x, Y.y);


                }



            }




        }






    }

    //
    //    LatLon interPos = getIntersectionPosition(closestInter1);
    //    Point interPosXY = conv_LatLon_to_XY(interPos);


    clik2 = true;





}











// didn't use this feature

void act_on_mouse_move(float x, float y) {
    // function to handle mouse move event, the current mouse position in the current world coordinate
    // system (as defined in your call to init_world) is returned

}


#include <X11/keysym.h>

void act_on_key_press(char c, int keysym) {

    // function to handle keyboard press event, the ASCII character is returned
    // along with an extended code (keysym) on X11 to represent non-ASCII
    // characters like the arrow keys.

    // DO THE STUFF HERE FOR THE DIALOGUE BOX

    std::cout << "Key press: char is " << c << std::endl;

#ifdef X11 // Extended keyboard codes only supported for X11 for now
    switch (keysym) {
        case XK_Left:
            std::cout << "Left Arrow" << std::endl;
            break;
        case XK_Right:
            std::cout << "Right Arrow" << std::endl;
            break;
        case XK_Up:
            std::cout << "Up Arrow" << std::endl;
            break;
        case XK_Down:
            std::cout << "Down Arrow" << std::endl;
            break;
        default:
            std::cout << "keysym (extended code) is " << keysym << std::endl;
            break;
    }
#endif

    int h = (int) c;



    // Enter pressed:
    //    double xleft = get_visible_world().left();
    //    double xright = get_visible_world().right();
    //    double yBottom = get_visible_world().bottom();
    //
    //    double yTop = (yBottom + get_visible_world().get_ycenter()) / 2;
    //
    //    double yoneFour = (yBottom + yTop) / 2;
    //
    //    t_point x_Location(xleft, yBottom);
    //    t_point y_Location(xright, yoneFour);
    //
    //    t_bound_box myTextBox(x_Location, y_Location);
    //
    //    setcolor(WHITE);
    //
    //    fillrect(xleft, yBottom, xright, yoneFour);
    //
    //    setcolor(BLACK);
    //
    //    setlinewidth(3);
    //
    //    setfontsize(15);
    //    drawrect(xleft, yBottom, xright, yoneFour);
    //
    //    t_point textCentre(((xleft + xright) / 2), ((yBottom + yoneFour) / 2));
    //    string text = "WELCOME:fwefwefwwefwef";
    //    settextrotation(0);
    //    if (h == 0x20) {
    //
    //        cout<<"END"<<endl;
    //        drawtext(textCentre, text, myTextBox);
    //
    //    }
    //

}

void act_on_help(void (*drawscreen_ptr) (void)) {
    double xleft = get_visible_world().left();
    double xright = get_visible_world().right();
    double yBottom = get_visible_world().bottom();

    double yTop = (yBottom + get_visible_world().get_ycenter()) / 2;

    double yoneFour = (yBottom + yTop) / 2;

    t_point x_Location(xleft, yBottom);
    t_point y_Location(xright, yoneFour);

    t_bound_box myTextBox(x_Location, y_Location);

    setcolor(WHITE);

    fillrect(xleft, yBottom, xright, yoneFour);

    setcolor(BLACK);

    setlinewidth(3);

    setfontsize(15);
    drawrect(xleft, yBottom, xright, yoneFour);

    t_point textCentre(((xleft + xright) / 2), ((yBottom + yoneFour) / 2));
    string text = "WELCOME: For quick start check the terminal window";
    //cout<<
    settextrotation(0);

    drawtext(textCentre, text, myTextBox);


    //cout.flush();//<<"\n";
    //cin.clear();
    //flush;

    if (run) {
        cout << "Map has been loaded\n";
        cout << "For detailed description type: \e[1m'help'\e[0m" << endl;
        getline(cin, command);


        if (command == "help") {
            cout << "Welcome to the MAPPER WIZZARD: type 1) Buttons or 2) General" << endl;

            while (1) {
                getline(cin, command);
                if (command == "buttons") {
                    cout << "BUTTONS MAPPING>>>>>>>" << endl;
                    cout << "\e[1mSwitchMap: \e[0mPress to take the command back to terminal and allow to choose map of your choice" << "" << endl;
                    cout << "\e[1mResetScreen: \e[0mPress to Refresh the screen after showing a route" << endl;
                    cout << "\e[1mRouteInterIds: \e[0mAllows you to select 2 intersection of you choice and returns path between them" << endl;
                    cout << "\e[1mFind: 2 features-> \e[0m1. P: Enter 2 street names and POI. Returns path between them" << endl;
                    cout << "                          2. I: Enter 4 streets names to return the path between 2 intersections" << endl;
                    cout << "type 'end' to exit the help" << endl;
                    run = false;
                } else if (command == "general") {
                    cout << "general info>>>>>>>>>" << endl;
                    cout << "1)Click any of the 2 points on the map to show path between them" << endl;
                    cout << ">>Scroll mouse wheel to zoom in and make the highlights appear" << endl;
                    cout << "2)Clicking on the intersection returns the intersection info" << endl;
                    cout << endl;
                    cout << "type 'end' to exit the help" << endl;
                    cout << "\e[1m***ONE WAY & PATH convention: (RED TO GREEN)***\e[0m" << endl;
                    run = false;
                }


                if (command == "end") {
                    run = false;
                    break;
                }
                //cin.clear();


            }
        }

    }
    run = true;
    //drawscreen();


    command.clear();


}

void act_on_Switch_Map_buttonPress(void (*drawscreen_ptr) (void)) {
    //clearscreen();
    close_graphics();
    close_map();
    mapInitializer();
}
