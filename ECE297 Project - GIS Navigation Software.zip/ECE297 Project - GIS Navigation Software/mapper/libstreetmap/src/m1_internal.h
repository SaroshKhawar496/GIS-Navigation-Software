
#ifndef M1_INTERNAL_H
#define M1_INTERNAL_H
#include "m1.h"
#include "dataStructs.h"
#include <vector>


using namespace std;

std::vector<unsigned> unit_test_output(std::string street_name,
        std::vector<std::string>& list);


double find_distance_squared_between_two_points(LatLon point1, LatLon point2);



#endif /* M1_INTERNAL_H */

