#pragma once
#include "dataStructs.h"
#include "mapLoder.h"

#include "m1.h"
#include <algorithm>

#include "graphics.h"

#include "cstdlib"
#include <readline/readline.h>
#include <readline/history.h>

#include <thread>
#include <chrono>
#include <vector>
#include <cfloat> // for FLT_MAX
#include <iostream>
#include <cmath>
#include <unistd.h>

void draw_map();
Point conv_LatLon_to_XY(LatLon point1);
void setBounds();
char** command_completion(const char* stem_text, int start, int end);
char* street_name_generator(const char* stem_text, int state);
char** command_completionPOI(const char* stem_text, int start, int end);
char* POI_name_generator(const char* stem_text, int state);
void showDirections(const std::vector<unsigned>& path,const std::vector<unsigned>& interIDsPath); 
std::vector<unsigned> find_path_between_intersections_for_showing_directions(unsigned 
                   intersect_id_start, unsigned intersect_id_end, std::vector<unsigned> &InterIDVec);
