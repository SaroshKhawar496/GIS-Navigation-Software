#include "mapLoder.h"
#include <ctime>
#include "m3.h"

string mapName;

void clearDataStructures() {


    hotelNameToIdMap.clear();

    osmdIdToNodeId_Map.clear();

    //map with key: intersection_Name and value: intersection ids vector
    Street_name_to_id_map.clear();
    //
    //map with key: street id and value: structure holding a vector for unsigned ids
    Street_id_to_all_intersections_map.clear();

    //map with key: street name and value: structure holding a vector for unsigned ids
    Street_Name_to_all_intersections_map.clear();

    //for function 3 maps POI name to all nearest intersection ids
    POI_NameToNearestIntersections.clear();




    //--------------------------------------------------------------------------

    // ---------------- Vectors ----------------------------------------

    // outer vector has street ids as index, each element is vector containing 
    // street segment ids of that street
    streetIds_streetSegsVector.clear();

    // outer vector has street ids as index, each element is the total length of that 
    // street as double
    streetIds_streetLenVector.clear();

    // outer vector has segment ids as index, each element is streetSegmentInfo 
    // data structure of that segment id


    streetSegmentInformationVec.clear();

    // outer vector has intersection ids as index, each element is LatLon structure 
    // of that intersection

    intersectionPositionVec.clear();

    //outer vector has point of interests as index, each element is index of 
    //the nearest intersection to that point

    nearestInterIDFromPOIVec.clear();

    //outer vector has streetIds as index and each element is the name of the 
    //corresponding street

    streetNames.clear();

    //outer vector has streetIds as index and each element is the name of the 
    //corresponding POI

    POINames.clear();

    // outer vector has intersection id as index, each element is vector containing 
    // street segment ids of that intersection

    intersectionIds_StreetSegsVector.clear();


    djKGraph.clear();

    interId_to_Parent_Inter_Id.clear();
    interId_to_SegId_Parent_Inter_Id.clear();

    interId_to_Parent_Inter_Id1.clear();
    interId_to_SegId_Parent_Inter_Id1.clear();


    //key: single pair of 2 intersection ids and value is their connected seg ID
    twoIntersections_Conn_SegID.clear();

    HotelPlots.clear();
    GolfCoursePlots.clear();
    AirportPlots.clear();
    RunwayPlots.clear();

    draw_Buildings.clear();
    draw_Parks.clear();
    draw_River.clear();




}

unsigned SegId_Between_two_Intersections1(unsigned intersection_id1, unsigned intersection_id2) {

    //vect1 will hold street_segments_ids of intersection 1
    vector<unsigned> vect1;

    vect1 = find_intersection_street_segments(intersection_id1);

    //temporary object
    StreetSegmentInfo tmpInfo;

    //looping through vect1  
    for (unsigned i = 0; i < vect1.size(); i++) {

        // reading each segment ids' Info_structure one by one
        tmpInfo = streetSegmentInformationVec[vect1[i]];

        //if the from of intersection 1 is same as of segment and the to of seg is same as intersection 2, 
        //both intersections are directly connected and {oneway won't matter}
        if (tmpInfo.from == intersection_id1 && tmpInfo.to == intersection_id2) {
            return vect1[i];
        }

        //if it's required to go in other direction, check: 
        if (tmpInfo.from == intersection_id2 && tmpInfo.to == intersection_id1) {
            //checking if seg is 1 way and the start point of the seg isn't equal
            //to starting intersection then you can't go this way

            if (tmpInfo.oneWay == true && tmpInfo.from != intersection_id1) {
                //we already made sure this condition won't be true
                //if the segment is double way then you can go this way
                //cout << "1. segId finder false reached\n";


            } else {
                return vect1[i];
            }
        }

    }
    //cout << "end of segId finder reached\n";

}

void mapInitializer() {

    //"/cad2/ece297s/public/maps/toronto.streets.bin"
    string name;
    string command;
    //run_again = false;

    cout << "Welcome to the MAP\n";
    cout <<"Available maps are: \n";
    cout << "Toronto, NewYork, Hamilton, London, Moscow, Cairo, Saint Helena\n";
    cout << "Enter map name to load: ";
    
    getline(cin, name);
    
    while (1){//run_again == true && run_once == true ){
        
    if (name == "toronto" || name == "TORONTO" || name == "Toronto") {
        mapName = "/cad2/ece297s/public/maps/toronto.streets.bin";
        break;
        

    } else if (name == "london" || name == "London") {

        mapName = "/cad2/ece297s/public/maps/london_england.streets.bin";
        break;
       

    } else if (name == "moscow" || name == "Moscow") {
        mapName = "/cad2/ece297s/public/maps/moscow.streets.bin";
        break;
       

    } else if (name == "hamilton" || name == "Hamilton") {
        mapName = "/cad2/ece297s/public/maps/hamilton_canada.streets.bin";
        break;
       

    } else if (name == "Newyork" || name == "newyork") {
        mapName = "/cad2/ece297s/public/maps/newyork.streets.bin";
        break;

    } else if (name == "cairo" || name == "Cairo") {
        mapName = "/cad2/ece297s/public/maps/cairo_egypt.streets.bin";
        break;
    }
    else if (name == "saint helena" || name == "Saint Helena") {
        mapName = "/cad2/ece297s/public/maps/saint_helena.streets.bin";
        break;
    }
    //else if (name == "")
    
    else {
        cout<<" Map not available: Please try again"<<endl;
        cout<<"Enter map name to load: ";
        getline(cin, name);
        //run_again = true;
    }
    
}

    
    

    string osmFileName = mapName;
    string cutstring = ".streets.bin";
    string::size_type i = osmFileName.find(cutstring);

    if (i != string::npos) {
        osmFileName.erase(i, cutstring.length());

    }

    osmFileName.append(".osm.bin");


    clearDataStructures();

    loadOSMDatabaseBIN(osmFileName);

    //Total number of nodes 
    unsigned long long OSMNodesTotal = getNumberOfNodes();

    for (unsigned long i = 0; i < OSMNodesTotal; i++) {
        const OSMNode* osmPtr = getNodeByIndex(i);

        unsigned long long osmId = osmPtr->id(); // =returns the osmid

        pair<unsigned long long, unsigned long long > myPair(osmId, i);
        osmdIdToNodeId_Map.insert(myPair);

    }

    //cout"\n";
    cout<<endl;
    cout << "++++Going to load map++++\n";

    load_map(mapName);
    

    draw_map();
    
    
       
     
    
    
    
    
  

    close_map();


}
