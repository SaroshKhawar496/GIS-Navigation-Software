



#ifndef ADJACENTINTERSECTION_H
#define ADJACENTINTERSECTION_H

#include "dataStructs.h"
#include "m1.h"



//going to make this return a vector containing pair of intersection id, street id to its neighbours
std::vector<adjIntersectionRet> adjacent_intersections(unsigned intersection_id);




#endif /* ADJACENTINTERSECTION_H */

