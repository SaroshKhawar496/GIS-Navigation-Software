
#include "m1.h"

using namespace std;

unsigned segId_Between_two_Intersections(unsigned intersection_id1, unsigned intersection_id2);
bool are_directly_connected1(unsigned intersection_id1, unsigned intersection_id2, unsigned & segIDtoRet);


// variables to store the total numbers of map features, they are loaded with
//values in load map function
unsigned numOfStreetSegs;
unsigned numOfIntersections;
unsigned numOfStreets;

double maxSpeed;

unsigned numOfPOI;
unsigned numOfFeatures;



//structures to hold generic used stl containers


//----------     UN ORDERED MAPS    ---------------------------

//map with key: intersection_Name and value: intersection ids vector
unordered_map<string, vector<unsigned> > Street_name_to_id_map;
//
//map with key: street id and value: structure holding a vector for unsigned ids
unordered_map<unsigned, idVecStruct > Street_id_to_all_intersections_map;

//map with key: street name and value: structure holding a vector for unsigned ids
unordered_map<string, idVecStruct > Street_Name_to_all_intersections_map;



unordered_map <unsigned long long, unsigned long long > osmdIdToNodeId_Map;

unordered_map <string, unsigned> hotelNameToIdMap;

unordered_map <unsigned, int> interId_to_SegId_Parent_Inter_Id;

//for function 3 maps POI name to all nearest intersection ids
unordered_map<string, vector<unsigned> >POI_NameToNearestIntersections;

unordered_map<unsigned, int> interId_to_Parent_Inter_Id1;
unordered_map<unsigned, int> interId_to_SegId_Parent_Inter_Id1;


//--------------------------------------------------------------------------

// ---------------- Vectors ----------------------------------------

// outer vector has street ids as index, each element is vector containing 
// street segment ids of that street
vector <idVecStruct> streetIds_streetSegsVector;

// outer vector has street ids as index, each element is the total length of that 
// street as double
vector <double> streetIds_streetLenVector;

// outer vector has segment ids as index, each element is streetSegmentInfo 
// data structure of that segment id
vector <StreetSegmentInfo> streetSegmentInformationVec;

//outer vector has point of interests as index, each element is index of 
//the nearest intersection to that point

vector <unsigned> nearestInterIDFromPOIVec;

// outer vector has intersection ids as index, each element is LatLon structure 
// of that intersection

vector <LatLon> intersectionPositionVec;

//outer vector has streetIds as index and each element is the name of the 
//corresponding street

vector <const char *> streetNames;

//outer vector has streetIds as index and each element is the name of the 
//corresponding POI

vector <const char *> POINames;

// outer vector has intersection id as index, each element is vector containing 
// street segment ids of that intersection

vector <idVecStruct> intersectionIds_StreetSegsVector;

//Vector to hold LatLon coordinates of all hotels to be drawn and their tags

vector <HotelInfo> HotelPlots;

vector <GolfCourseInfo> GolfCoursePlots;

vector <AirportInfo> AirportPlots;

vector <RunwayInfo> RunwayPlots;

vector <unsigned> draw_Buildings;
vector <unsigned> draw_Parks;
vector <unsigned> draw_River;

unordered_map < unsigned, vector< djKStruct> > djKGraph;

unordered_map<unsigned, int> interId_to_Parent_Inter_Id;

map < pair <unsigned, unsigned>, unsigned > twoIntersections_Conn_SegID;

//--------------------------- Functions  -----------------------

bool load_map(std::string map_name) {

    bool load_success = loadStreetsDatabaseBIN(map_name);
    //Need .osm.bin instead of streets.bin to load OSM database
    numOfStreetSegs = getNumberOfStreetSegments();
    numOfPOI = getNumberOfPointsOfInterest();
    numOfIntersections = getNumberOfIntersections();
    numOfStreets = getNumberOfStreets();
    numOfFeatures = getNumberOfFeatures();

    maxSpeed = 0.0;


    setBounds();


    //filtering out the parks, buildings and rivers from the features to draw them
    // in m2.cpp  
    for (unsigned i = 0; i < numOfFeatures; i++) {

        unsigned featureType = getFeatureType(i);


        if (featureType == 7) {
            draw_Buildings.push_back(i);
        } else if (featureType == 1) {
            draw_Parks.push_back(i);
        } else if (featureType == 4) {
            draw_River.push_back(i);
        }


    }

    //Total number of ways

    unsigned long long OSMWaysTotal = getNumberOfWays();
    //Temporary data structures to push back into vector before actual data is 
    //recevied 

    HotelInfo Hotels;
    GolfCourseInfo GolfCourse;
    AirportInfo Airport;
    RunwayInfo Runway;

    LatLon t(0, 0);
    Hotels.coordinates = t;
    int hotelIndex = 0;
    int golfcourseIndex = 0; //newly added
    int AirportIndex = 0;
    int RunwayIndex = 0;


    bool HotelFound;
    bool golfCourseFound;
    bool AirportFound;
    bool RunwayFound;

    //Loop through all the ways in the map and look for all hotels,golfcourses,
    //airports,runways present

    for (unsigned long i = 0; i < OSMWaysTotal; i++) {

        const OSMWay* temp = getWayByIndex(i);
        HotelFound = false;
        golfCourseFound = false;
        AirportFound = false;
        RunwayFound = false;


        //Get all tags associated with current OSMway
        unsigned TagCount = getTagCount(temp);
        //Loop through all tags, if an intended tag (i.e Hotel etc...) is find,
        //get remaining required information

        for (unsigned j = 0; j < TagCount && (!HotelFound || !golfCourseFound || !AirportFound || !RunwayFound); j++) {

            //Get current key,value pair 
            std::pair<std::string, std::string> test = getTagPair(temp, j);

            if (test.second == "hotel") {
                //set flag
                HotelFound = true;
                //Push in empty structure as a temporary object which will be
                //filled with appropriate data later on 
                HotelPlots.push_back(Hotels);
            }


            if (test.second == "golf_course") {
                golfCourseFound = true;

                GolfCoursePlots.push_back(GolfCourse);
            }

            if (test.second == "terminal") {
                AirportFound = true;

                AirportPlots.push_back(Airport);
            }

            if (test.second == "runway") {
                RunwayFound = true;

                RunwayPlots.push_back(Runway);
            }

        }

        //-------------------------FILTERRING RUNWAY ---------------

        if (RunwayFound == true) {
            const std::vector<unsigned long long> noderef = temp->ndrefs();

            for (unsigned i = 0; i < noderef.size(); i++) {

                unsigned long long nodeId = osmdIdToNodeId_Map.at(noderef[i]);

                const OSMNode* tas = getNodeByIndex(nodeId);

                Point RunwayPosXY = conv_LatLon_to_XY(tas->coords());

                RunwayPlots[RunwayIndex].coordinatesXYVec.push_back(RunwayPosXY);

            }

            for (unsigned int j = 0; j < TagCount; j++) {
                //Get current key,value pair up to a maximum of 4 key value pairs 
                //if (j < 6) {
                std::pair<std::string, std::string> tag = getTagPair(temp, j);
                //if tag.first == name then add the name in the hotel structure
                //name is in the .second store that
                if (tag.first == "aeroway") { //"nam
                    //GolfCoursePlots[golfcourseIndex].tags.push_back(tag);
                    RunwayPlots[RunwayIndex].runwayName = tag.second;
                }


                RunwayPlots[RunwayIndex].tags.push_back(tag);

            }

            RunwayIndex++;

        }



        //------------------------- FILTERING AIRPORTS ---------------
        if (AirportFound == true) {
            const std::vector<unsigned long long> noderef = temp->ndrefs();

            for (unsigned i = 0; i < noderef.size(); i++) {

                unsigned long long nodeId = osmdIdToNodeId_Map.at(noderef[i]);

                const OSMNode* tas = getNodeByIndex(nodeId);

                Point AirportPosXY = conv_LatLon_to_XY(tas->coords());

                AirportPlots[AirportIndex].coordinatesXYVec.push_back(AirportPosXY);

            }

            for (unsigned int j = 0; j < TagCount; j++) {
                //Get current key,value pair up to a maximum of 4 key value pairs 
                //if (j < 6) {
                std::pair<std::string, std::string> tag = getTagPair(temp, j);
                //if tag.first == name then add the name in the hotel structure
                //name is in the .second store that
                if (tag.first == "aeroway") { //"nam
                    //GolfCoursePlots[golfcourseIndex].tags.push_back(tag);
                    //cout << "tag secomd: " << tag.second;
                    AirportPlots[AirportIndex].airportName = tag.second;
                }


                AirportPlots[AirportIndex].tags.push_back(tag);

                //cout << GolfCoursePlots[golfcourseIndex].tags[j].first << " " << GolfCoursePlots[golfcourseIndex].tags[j].second << "\n";


            }

            AirportIndex++;

        }


        // ----------------------------- FILTERING GOLF COURSES --------------
        if (golfCourseFound == true) {
            const std::vector<unsigned long long> noderef = temp->ndrefs();


            for (unsigned i = 0; i < noderef.size(); i++) {

                unsigned long long nodeId = osmdIdToNodeId_Map.at(noderef[i]);

                const OSMNode* tas = getNodeByIndex(nodeId);

                Point golfPosXY = conv_LatLon_to_XY(tas->coords());


                GolfCoursePlots[golfcourseIndex].coordinatesXYVec.push_back(golfPosXY);

            }
            for (unsigned int j = 0; j < TagCount; j++) {
                std::pair<std::string, std::string> tag = getTagPair(temp, j);

                //if tag.first == name then add the name in the hotel structure
                //name is in the .second store that

                if (tag.first == "leisure") { //"nam
                    //GolfCoursePlots[golfcourseIndex].tags.push_back(tag);
                    //cout << "tag secomd: " << tag.second;
                    GolfCoursePlots[golfcourseIndex].GolfCourseName = tag.second;
                }


                GolfCoursePlots[golfcourseIndex].tags.push_back(tag);


            }

            golfcourseIndex++;

        }

        // ------------------------------- FILTERING HOTELS ------------------

        if (HotelFound == true) {

            //Get list of nodes making up this area (hotel)
            const std::vector<unsigned long long> noderef = temp->ndrefs();

            //Hotel is being visualized as a point, so get starting nodeID from
            //corresponding OSMId making up this OSMway
            unsigned long long nodeId = osmdIdToNodeId_Map.at(noderef[0]);

            const OSMNode* tas = getNodeByIndex(nodeId);
            //Store the coordinates of this node 
            HotelPlots[hotelIndex].coordinates = tas->coords();

            for (unsigned int j = 0; j < TagCount; j++) {
                std::pair<std::string, std::string> tag = getTagPair(temp, j);
                //if tag.first == name then add the name in the hotel structure
                //name is in the .second store that
                if (tag.first == "name") { //"name
                    HotelPlots[hotelIndex].hotelName = tag.second;
                    hotelNameToIdMap[tag.second] = hotelIndex;

                }

                //Store all tags associated with this hotel 
                HotelPlots[hotelIndex].tags.push_back(tag);

            }
            //Increment counter to indicate that one hotel has been added to
            //the list 
            hotelIndex++;
        }

    }

    // --------------------------------------------------------------

    idVecStruct empIdsStruct;

    //nested for loops to fill intersectionIds&streetSegmentsMap
    //cout << "going to run the intersections loop\n";

    // 99999999999999999999999999999999999999999999999999999999------START----------

    for (unsigned j = 0; j < numOfIntersections; j++) {

        // Returns connected intersections for a particular intersection  
        //vector <unsigned> adjInterIdsVec = find_adjacent_intersections(j);
        // Returns street_seg_ids (all)

        //        cout << "finished filling main part\n";

        intersectionPositionVec.push_back(getIntersectionPosition(j));

        //empty structure declared inside the loop to prevent clearing 
        //after use
        idVecStruct fillingVectorStr;

        //getting num of street segments attached to jth intersection
        unsigned streetSegCount = getIntersectionStreetSegmentCount(j);

        //filling the vector with empty structure so it can be filled later with
        //data
        intersectionIds_StreetSegsVector.push_back(empIdsStruct);

        //loop to fill all the street segment ids for jth intersection
        for (unsigned i = 0; i < streetSegCount; i++) {
            unsigned segId = getIntersectionStreetSegment(j, i);
            fillingVectorStr.idVec.push_back(segId);
        }


        //putting the filled structure fillingVectorStr into its place in the map 
        intersectionIds_StreetSegsVector[j] = fillingVectorStr;



    }

    //999999999999999999999999999999999----------END------------99999999999999999999999999999999999999999999

    //tmp variable to load the length of each street in streetId and street lenth map
    double initStreetLength = 0.0;

    //empty variables to fill the data structures
    std::vector<unsigned> street_ids_Emp;
    intersecectionIdSetStruct empSetInterId;
    idVecStruct empVecStruct;


    //this loops initializes the streetIds_streetSegsMap with ids and empty vectors at each id
    // and the length of each street in streetIds_streetLenMap, is initialized to zero

    for (unsigned stId = 0; stId < numOfStreets; stId++) {

        string stName = getStreetName(stId);
        //Generate vector that holds all streetNames in the current map
        streetNames.push_back(stName.c_str());
        //---------------------------------------------------------
        //filling the maps/vectors with empty data structures so it can be 
        //filled in the latter loop
        Street_name_to_id_map[stName] = street_ids_Emp;

        Street_id_to_all_intersections_map[stId] = empVecStruct;

        Street_Name_to_all_intersections_map[stName] = empVecStruct;

        streetIds_streetSegsVector.push_back(empIdsStruct);
        //  -------------------------------------------------------------

        //initializing the streetIds_streetLenVector with 0, so it can be filled
        // in the latter loop
        streetIds_streetLenVector.push_back(initStreetLength);
    }


    for (unsigned segId = 0; segId < numOfStreetSegs; segId++) {

        //intermediate variables
        StreetSegmentInfo fillSeg = getStreetSegmentInfo(segId);

        //need max speed of city for a star h value
        if (fillSeg.speedLimit > maxSpeed) {
            maxSpeed = fillSeg.speedLimit;
        }




        unsigned street_id = getStreetSegmentInfo(segId).streetID;

        string stName = getStreetName(fillSeg.streetID);

        //+++++++++++++++++++FILLING  Street_name_to_id_map +++++++++++++++++++

        Street_name_to_id_map[stName].push_back(street_id);

        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        //intermediate variables
        unsigned segFrom = fillSeg.from;
        unsigned segTo = fillSeg.to;

        //Filling the map's sets with data. TThere would be  duplicates in this
        //map, but they are dealt with in the functions that use this map 

        Street_id_to_all_intersections_map[street_id].idVec.push_back(segFrom);
        Street_id_to_all_intersections_map[street_id].idVec.push_back(segTo);

        //Filling the map's vectors with data. There would be  duplicates in this
        //map, but they are dealt with in the functions that use this map     
        Street_Name_to_all_intersections_map[stName].idVec.push_back(segFrom);
        Street_Name_to_all_intersections_map[stName].idVec.push_back(segTo);

        //filling the  vector with segmentInfo structure
        streetSegmentInformationVec.push_back(fillSeg);


        //intermediate variable using our own streetSegmentInformationVec
        //this makes load map perform faster
        unsigned newStId = streetSegmentInformationVec[segId].streetID;

        // filling the vector by adding to the total length of each street at 
        // respective street index

        streetIds_streetLenVector[newStId] += find_street_segment_length(segId);

        //filling the inner vectors with segment ids, of streetIds_streetSegsVector 
        streetIds_streetSegsVector[newStId].idVec.push_back(segId);

    }




    //    // cout << "our another loop\n";
    //    for (unsigned j = 0; j < numOfIntersections; j++) {
    //
    //
    //
    //        //first is adj id , then street id
    ////        vector <adjIntersectionRet> adjIntersectionsVec = adjacent_intersections(j);
    ////
    ////
    ////        if (adjIntersectionsVec.size() != 0) {
    ////
    ////
    ////            djKStruct myGraphStruct;
    ////            for (unsigned k = 0; k < adjIntersectionsVec.size(); k++) {
    ////
    ////
    ////
    ////                double Seg_travel_time = find_street_segment_travel_time(adjIntersectionsVec[k].segmentId_);
    ////
    ////                myGraphStruct.adj_IntersectionId = adjIntersectionsVec[k].adjInterId_;
    ////                myGraphStruct.streetIdOfAdj = adjIntersectionsVec[k].streetId_;
    ////                myGraphStruct.travelTimeToAdj = Seg_travel_time;
    ////                myGraphStruct.segmentIdOfAdj=adjIntersectionsVec[k].segmentId_;
    ////                
    ////                djKGraph[j].push_back(myGraphStruct);
    ////
    ////
    ////
    ////            }
    ////
    ////        } 
    //
    //    }

    //Find nearest point of intersection (geographically) to each point of interest
    //in the map



    //cout << "here2\n";

    for (unsigned j = 0; j < numOfIntersections; j++) {

        // Returns connected intersections for a particular intersection  
        //vector <unsigned> adjInterIdsVec = find_adjacent_intersections(j);
        // Returns street_seg_ids (all)

        //        cout << "finished filling main part\n";

        intersectionPositionVec.push_back(getIntersectionPosition(j));

        //empty structure declared inside the loop to prevent clearing 
        //after use
        idVecStruct fillingVectorStr;

        //getting num of street segments attached to jth intersection
        unsigned streetSegCount = getIntersectionStreetSegmentCount(j);

        //filling the vector with empty structure so it can be filled later with
        //data
        intersectionIds_StreetSegsVector.push_back(empIdsStruct);

        //loop to fill all the street segment ids for jth intersection
        for (unsigned i = 0; i < streetSegCount; i++) {
            unsigned segId = getIntersectionStreetSegment(j, i);
            fillingVectorStr.idVec.push_back(segId);
        }


        //putting the filled structure fillingVectorStr into its place in the map 
        intersectionIds_StreetSegsVector[j] = fillingVectorStr;


    }
    //  cout << "here1\n";
    for (unsigned i = 0; i < numOfPOI; i++) {
        //unsigned intersectionIndex = find_closest_intersection(getPointOfInterestPosition(i));
        string POIName = getPointOfInterestName(i);
        POINames.push_back(POIName.c_str());
    }




    for (unsigned j = 0; j < numOfIntersections; j++) {

        vector <adjIntersectionRet> adjIntersectionsVec = adjacent_intersections(j);


        if (adjIntersectionsVec.size() != 0) {


            djKStruct myGraphStruct;

            for (unsigned k = 0; k < adjIntersectionsVec.size(); k++) {



                double Seg_travel_time = find_street_segment_travel_time(adjIntersectionsVec[k].segmentId_);

                myGraphStruct.adj_IntersectionId = adjIntersectionsVec[k].adjInterId_;
                myGraphStruct.streetIdOfAdj = adjIntersectionsVec[k].streetId_;
                myGraphStruct.travelTimeToAdj = Seg_travel_time;
                myGraphStruct.segmentIdOfAdj = adjIntersectionsVec[k].segmentId_;

                djKGraph[j].push_back(myGraphStruct);



            }

        }




    }



    return load_success;
}



//function to return street id(s) for a street name
//return a 0-length vector if no street with this name exists.

std::vector<unsigned> find_street_ids_from_name(std::string street_name) {

    vector <unsigned> retVec;
    //try finding the name if it exists in the map
    auto it = Street_name_to_id_map.find(street_name);

    //if the name exists, get the vector at the key   
    if (it != Street_name_to_id_map.end()) {
        //it->second

        retVec = it->second;

        //sorting the vector
        sort(retVec.begin(), retVec.end());

        //removing the duplicates from the vector
        retVec.erase(unique(retVec.begin(), retVec.end()), retVec.end());

        //return the vector
        return retVec;

    }
    //if name isn't found return empty vector
    return retVec;


}

//helper function to assist unit test written for above function

std::vector<unsigned> unit_test_output(std::string street_name,
        std::vector<std::string>& list) {
    std::vector<unsigned> street_ids_vector;
    unsigned i;
    for (i = 0; i < numOfStreets; i++) {
        if (street_name == list[i]) {
            street_ids_vector.push_back(i);
        }

    }
    return street_ids_vector;
}




//function to return the street segments for a given intersection 
//checked in main function fills the vector variable in main properly.

std::vector<unsigned> find_intersection_street_segments(unsigned intersection_id) {


    //return intersectionIds_StreetSegsMap.at(intersection_id);
    return intersectionIds_StreetSegsVector[intersection_id].idVec;

}



//function to return street names at an intersection (include duplicate street names in returned vector)
//checked the function properly in main function, filling the vector variable properly and showing proper names 

std::vector<std::string> find_intersection_street_names(unsigned intersection_id) {

    //variables to be used in the function
    std::vector<std::string> streetNamesVec;

    std::string stName;

    StreetSegmentInfo streetSegInfo;

    std::vector<unsigned> tmpVec;

    unsigned tmpStId;

    //vector holding street segment ids for the given intersection id
    tmpVec = find_intersection_street_segments(intersection_id);

    // Looping over all the segments and getting seg_info from our vector structure 
    for (unsigned i = 0; i < tmpVec.size(); i++) {

        //getting the streetSegmentInfo for the ith id in tmpVec
        streetSegInfo = streetSegmentInformationVec[tmpVec[i]];

        //getting street id from streetSegInfo
        tmpStId = streetSegInfo.streetID;

        //getting street name from street id
        stName = getStreetName(tmpStId);

        //putting the name in the return vector
        streetNamesVec.push_back(stName);

    }

    return streetNamesVec;
}

//our modified fxn to return seg id connecting those 2 intersections

bool are_directly_connected1(unsigned intersection_id1, unsigned intersection_id2, unsigned & segIDtoRet) {

    //if both are same intersections return true
    if (intersection_id1 == intersection_id2) {
        return true;
    }

    //vect1 will hold street_segments_ids of intersection 1
    vector<unsigned> vect1;

    vect1 = find_intersection_street_segments(intersection_id1);

    //temporary object
    StreetSegmentInfo tmpInfo;

    //looping through vect1  
    for (unsigned i = 0; i < vect1.size(); i++) {

        // reading each segment ids' Info_structure one by one
        tmpInfo = streetSegmentInformationVec[vect1[i]];

        //if the from of intersection 1 is same as of segment and the to of seg is same as intersection 2, 
        //both intersections are directly connected and {oneway won't matter}

        if (tmpInfo.from == intersection_id1 && tmpInfo.to == intersection_id2) {
            segIDtoRet = vect1[i];
            return true;
        }

        //if it's required to go in other direction, check: 
        if (tmpInfo.from == intersection_id2 && tmpInfo.to == intersection_id1) {
            //checking if seg is 1 way and the start point of the seg isn't equal
            //to starting intersection then you can't go this way

            if (tmpInfo.oneWay == true && tmpInfo.from != intersection_id1) {
                return false;

                //if the segment is double way then you can go this way
            } else {
                segIDtoRet = vect1[i];
                return true;
            }
        }

    }

    // if no case is satisfied then the intersections are not connected
    return false;
}



















//function to check if the two intersections are directly connected,
//ie if you can get from intersection1 to intersection2 using single street 
//segment

bool are_directly_connected(unsigned intersection_id1, unsigned intersection_id2) {

    //if both are same intersections return true
    if (intersection_id1 == intersection_id2) {
        return true;
    }

    //vect1 will hold street_segments_ids of intersection 1
    vector<unsigned> vect1;

    vect1 = find_intersection_street_segments(intersection_id1);

    //temporary object
    StreetSegmentInfo tmpInfo;

    //looping through vect1  
    for (unsigned i = 0; i < vect1.size(); i++) {

        // reading each segment ids' Info_structure one by one
        tmpInfo = streetSegmentInformationVec[vect1[i]];

        //if the from of intersection 1 is same as of segment and the to of seg is same as intersection 2, 
        //both intersections are directly connected and {oneway won't matter}

        if (tmpInfo.from == intersection_id1 && tmpInfo.to == intersection_id2) {
            return true;
        }

        //if it's required to go in other direction, check: 
        if (tmpInfo.from == intersection_id2 && tmpInfo.to == intersection_id1) {
            //checking if seg is 1 way and the start point of the seg isn't equal
            //to starting intersection then you can't go this way

            if (tmpInfo.oneWay == true && tmpInfo.from != intersection_id1) {
                return false;

                //if the segment is double way then you can go this way
            } else {
                return true;
            }
        }

    }

    // if no case is satisfied then the intersections are not connected
    return false;
}

unsigned segId_Between_two_Intersections(unsigned intersection_id1, unsigned intersection_id2) {

    //vect1 will hold street_segments_ids of intersection 1
    vector<unsigned> vect1;

    vect1 = find_intersection_street_segments(intersection_id1);

    //temporary object
    StreetSegmentInfo tmpInfo;

    //looping through vect1  
    for (unsigned i = 0; i < vect1.size(); i++) {

        // reading each segment ids' Info_structure one by one
        tmpInfo = streetSegmentInformationVec[vect1[i]];

        //if the from of intersection 1 is same as of segment and the to of seg is same as intersection 2, 
        //both intersections are directly connected and {oneway won't matter}
        if (tmpInfo.from == intersection_id1 && tmpInfo.to == intersection_id2) {
            return vect1[i];
        }

        //if it's required to go in other direction, check: 
        if (tmpInfo.from == intersection_id2 && tmpInfo.to == intersection_id1) {
            //checking if seg is 1 way and the start point of the seg isn't equal
            //to starting intersection then you can't go this way

            if (tmpInfo.oneWay == true && tmpInfo.from != intersection_id1) {
                //we already made sure this condition won't be true
                //if the segment is double way then you can go this way
                // cout << "1. segId finder false reached\n";


            } else {
                return vect1[i];
            }
        } else {
            //cout << "2. segidfinder false reached\n";
        }

    }
    // cout << "end of segId finder reached\n";

}




//BACKUP //enable the sets back!!!!!!!

std::vector<unsigned> find_adjacent_intersections(unsigned intersection_id) {


    //temp variables ------------------------------
    //    std::set <unsigned> tmpSet;

    std::vector<unsigned> adjacent_inter;

    StreetSegmentInfo streetSeg_struct;

    unsigned segId;

    //--------------------------------------------------

    unsigned intersections_count = getIntersectionStreetSegmentCount(intersection_id);

    // Have to check for a 1 way road 
    for (unsigned i = 0; i < intersections_count; i++) {

        //segId is street segment id for that intersection
        segId = getIntersectionStreetSegment(intersection_id, i);
        //Using the street segment id to get all the info
        // Have to check for street segment connections and 1-ways
        streetSeg_struct = streetSegmentInformationVec[segId];

        if (streetSeg_struct.from == intersection_id) {
            //i.e adjacent intersection is a "to", hence, connected 
            // 
            //push in the street id in it make a strtucutre return vector
            adjacent_inter.push_back(streetSeg_struct.to);
        }//For the case if the from & to are flipped but the road is 2-way

        else if (streetSeg_struct.to == intersection_id) {
            //Segment may start from the other end but if it is 
            // !1-way, still adjacent 
            if (streetSeg_struct.oneWay == true) {

            } else {
                adjacent_inter.push_back(streetSeg_struct.from);
            }
        }

    }



    //putting data of set back into vector
    return adjacent_inter;

}




















//for a given street id, return all the street segments ids

std::vector<unsigned> find_street_street_segments(unsigned street_id) {

    // Returns the street_segment vector from the streetIds_streetSegsVector, our
    //data structure
    return streetIds_streetSegsVector [street_id].idVec;

}


//for a given street id, find all the intersections ids

std::vector<unsigned> find_all_street_intersections(unsigned street_id) {

    //getting the set from the map at the given street id
    vector <unsigned> tmpVec = Street_id_to_all_intersections_map.at(street_id).idVec;

    //sorting the vector
    sort(tmpVec.begin(), tmpVec.end());
    //removing the duplicates
    tmpVec.erase(unique(tmpVec.begin(), tmpVec.end()), tmpVec.end());


    return tmpVec;


}

//function to return all intersection ids for two intersecting streets
//this function will typically return one intersection id between two street names
//but duplicate street names are allowed, so more than 1 intersection id may exist for 2 street names

std::vector<unsigned> find_intersection_ids_from_street_names(std::string street_name1, std::string street_name2) {


    //Getting all the intersection ids for each street_name
    vector <unsigned> vec1 = Street_Name_to_all_intersections_map.at(street_name1).idVec;
    vector <unsigned> vec2 = Street_Name_to_all_intersections_map.at(street_name2).idVec;

    //vector to hold common intersection ids from both vec1 and vec2
    vector <unsigned> commonVec;

    //sorting and removing duplicates from each vec1
    sort(vec1.begin(), vec1.end());
    vec1.erase(unique(vec1.begin(), vec1.end()), vec1.end());

    //sorting and removing duplicates from each vec2
    sort(vec2.begin(), vec2.end());
    vec2.erase(unique(vec2.begin(), vec2.end()), vec2.end());

    //taking the common ids from the vec1 and vec2, and putting the result in 
    //commonVec vector
    set_intersection(vec1.begin(), vec1.end(), vec2.begin(), vec2.end(), back_inserter(commonVec));


    return commonVec;

}

//Helper function to find distance squared between two coordinates

double my_cosine(double Avg) {


    return (1 - ((Avg * Avg) / 2) + ((Avg * Avg * Avg * Avg) / 24));
}

double find_distance_squared_between_two_points_2(LatLon point1, LatLon point2) {
    //Two variables to hold calculated (x,y) coordinates of given LatLon Points 
    Point P1;
    Point P2;
    //compute latitude average between given two points
    double latAverage = ((point1.lat * DEG_TO_RAD) + (point2.lat * DEG_TO_RAD)) / 2.0;
    P1.x = ((point1.lon * DEG_TO_RAD) * my_cosine(latAverage));

    P1.y = (point1.lat * DEG_TO_RAD);

    P2.x = ((point2.lon * DEG_TO_RAD) * my_cosine(latAverage));

    P2.y = (point2.lat * DEG_TO_RAD);
    //Compute distance squared between the given two points
    double distance = ((P2.y - P1.y)*(P2.y - P1.y) +
            ((P2.x - P1.x)*(P2.x - P1.x)));
    return distance;
}






double find_distance_squared_between_two_points(LatLon point1, LatLon point2) {
    //Two variables to hold calculated (x,y) coordinates of given LatLon Points 
    Point P1;
    Point P2;
    //compute latitude average between given two points
    double latAverage = ((point1.lat * DEG_TO_RAD) + (point2.lat * DEG_TO_RAD)) / 2.0;
    P1.x = ((point1.lon * DEG_TO_RAD) * cos(latAverage));

    P1.y = (point1.lat * DEG_TO_RAD);

    P2.x = ((point2.lon * DEG_TO_RAD) * cos(latAverage));

    P2.y = (point2.lat * DEG_TO_RAD);
    //Compute distance squared between the given two points
    double distance = ((P2.y - P1.y)*(P2.y - P1.y) +
            ((P2.x - P1.x)*(P2.x - P1.x)));
    return distance;
}

//find distance between two coordinates

double find_distance_between_two_points(LatLon point1, LatLon point2) {

    //getting squared distance from helper function
    double distSquared = find_distance_squared_between_two_points(point1, point2);

    //computing final distance
    double distance = EARTH_RADIUS_IN_METERS * sqrt(distSquared);

    return distance;
}

//find the length of a given street segment

double find_street_segment_length(unsigned street_segment_id) {
    StreetSegmentInfo street = getStreetSegmentInfo(street_segment_id);
    //Get curve point count
    unsigned curveCount = street.curvePointCount;
    //If curveCount is 0, it is a straight line segment, calculate distance 
    //between two intersection points
    if (curveCount == 0) {
        LatLon one = getIntersectionPosition(street.from);
        LatLon two = getIntersectionPosition(street.to);
        double distance = find_distance_between_two_points(one, two);
        return distance;
    } else {
        //Create a LatLon array to hold all curve points plus starting and end
        //points of line segment
        LatLon *tmpArr = new LatLon[curveCount + 2];

        tmpArr[0] = getIntersectionPosition(street.from);

        tmpArr[curveCount + 1] = getIntersectionPosition(street.to);
        double distance = 0.0;
        //Loop through all curve points and calculate distance contribution to
        //each individual segment in the entire line segment
        //added -1 here
        for (unsigned i = 0; i < curveCount; i++) {
            tmpArr[i + 1] = getStreetSegmentCurvePoint(street_segment_id, i);
            distance += find_distance_between_two_points(tmpArr[i], tmpArr[i + 1]);
        }
        //Compute distance between final curve point and the second intersection
        //that the segment is connected to 
        distance += find_distance_between_two_points(tmpArr[curveCount], tmpArr[curveCount + 1]);
        delete []tmpArr;
        return distance;
    }
}

//find the length of a whole street

double find_street_length(unsigned street_id) {
    // Get the length value from the vector which is indexed by street id
    return streetIds_streetLenVector[street_id];
}

//find the travel time to drive a street segment (time(minutes) = 
//distance(km)/speed_limit(km/hr) * 60

double find_street_segment_travel_time(unsigned street_segment_id) {
    //Calculate the distance in kilometers 
    double distance = (find_street_segment_length(street_segment_id)) / 1000.0;
    //Get street segment speed limit
    double speedLimit = streetSegmentInformationVec[street_segment_id].speedLimit;
    //Calculate time required to drive on street segment 
    double time = (distance / speedLimit)*60.0;
    return time;
}

//find the nearest point of interest to a given position

unsigned find_closest_point_of_interest(LatLon my_position) {
    //Compute distance between myPosition and PointOfInterest(0)
    double distance = find_distance_squared_between_two_points(my_position,
            getPointOfInterestPosition(0));
    //If point of interest and current location are the same, return ID 0
    if (distance == 0) {
        return 0;
    }

    unsigned nearestPointID = 0;
    //Compute distance between myPosition and all points of interest in the 
    //city 
    int const numPtsOfInterest = (int) numOfPOI;
    for (int i = 1; i < numPtsOfInterest; i++) {
        double intermediate = find_distance_squared_between_two_points(my_position,
                getPointOfInterestPosition(i));
        if (intermediate == 0) {
            return i;
        }//If calculated distance in this iteration is less than current value
            //of distance, update the distance value and the ID value 
        else if (intermediate < distance) {
            distance = intermediate;
            nearestPointID = i;
        }
    }
    return nearestPointID;
}

//find the nearest intersection (by ID) to a given position

unsigned find_closest_intersection(LatLon my_position) {
    //Compute distance between myPosition and Intersection(0)
    double distance = find_distance_squared_between_two_points(my_position,
            intersectionPositionVec[0]);
    //If intersection and current location are the same, return ID 0
    if (distance == 0) {
        return 0;
    }

    unsigned nearestPointID = 0;
    int const totalIntersections = (int) numOfIntersections;
    //Compute distance between myPosition and all intersections in the 
    //city 
    for (int i = 1; i < totalIntersections; i++) {
        double intermediate = find_distance_squared_between_two_points(my_position,
                intersectionPositionVec[i]);
        if (intermediate == 0) {
            return i;
        }//If calculated distance in this iteration is less than current value
            //of distance, update the distance value and the ID value 
        else if (intermediate < distance) {
            distance = intermediate;
            nearestPointID = i;
        }
    }
    return nearestPointID;

}

//close the map
//No dynamically created structures so no deleting in close map()

void close_map() {
    closeStreetDatabase();
    closeOSMDatabase();

}
//  adjacent_inter.assign(tmpSet.begin(), tmpSet.end());

