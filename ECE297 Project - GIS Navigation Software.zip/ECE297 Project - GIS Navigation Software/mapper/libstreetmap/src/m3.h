#pragma once

#include "m1.h"
#include "m2.h"
#include "dataStructs.h"
#include "easygl_constants.h"
#include "easygl_constants.h"


#include <vector>
#include <string>


// Returns a path (route) between the start intersection and the end 
// intersection, if one exists. If no path exists, this routine returns 
// an empty (size == 0) vector. If more than one path exists, the path 
// with the shortest travel time is returned. The path is returned as a vector 
// of street segment ids; traversing these street segments, in the given order,
// would take one from the start to the end intersection.
std::vector<unsigned> find_path_between_intersections(unsigned
        intersect_id_start, unsigned intersect_id_end);

//std::vector<unsigned> find_path_m4(unsigned &intersect_id_start, set <unsigned>& dropOffIntersSet, vector<bool>& didPickupVec);

// Returns the time required to travel along the path specified. The path
// is passed in as a vector of street segment ids, and this function can 
// assume the vector either forms a legal path or has size == 0.
// The travel time is the sum of the length/speed-limit of each street 
// segment, plus 15 seconds per turn implied by the path. A turn occurs
// when two consecutive street segments have different street names.
double compute_path_travel_time(const std::vector<unsigned>& path);


// Returns the shortest travel time path (vector of street segments) from 
// the start intersection to a point of interest with the specified name.
// If no such path exists, returns an empty (size == 0) vector.
std::vector<unsigned> find_path_to_point_of_interest(unsigned
        intersect_id_start, std::string point_of_interest_name);

unsigned find_closest_point_of_interest_by_name(LatLon my_position, std::string POI_Name);
vector<unsigned> find_all_closest_point_of_interest_by_name(LatLon my_position, std::string POI_Name);