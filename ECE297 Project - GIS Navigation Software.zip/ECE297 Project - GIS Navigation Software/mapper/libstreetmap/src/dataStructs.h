
#ifndef DATASTRUCTS_H
#define DATASTRUCTS_H

#include <iostream>
#include <set>
#include <unordered_map>
#include <map>
#include <vector>
#include "StreetsDatabaseAPI.h"


using namespace std;


// variables to store the total numbers of map features, they are loaded with
//values in load map function
extern unsigned numOfStreetSegs;
extern unsigned numOfIntersections;
extern unsigned numOfStreets;
extern unsigned numOfPOI;
extern unsigned numOfFeatures;

//max city speed
extern double maxSpeed;

//m4 stuff//////////////////////////
extern unordered_map <unsigned, set<unsigned> > pickupToDropOffMap;
extern unordered_map <unsigned, set<unsigned> > dropOffToPickupMap;

extern set<unsigned> totalPickups; //all the unique pickups intersections
//extern set<unsigned> allDropOffIdsSet;
extern vector<unsigned> pickupsDone;

extern vector <unsigned> totalPathForM4;

///////////////////////////////////////

extern LatLon minLatLon_;
extern LatLon MaxLatLon_;

typedef struct {
    double x;
    double y;
} Point;

struct idVecStruct {
    vector <unsigned> idVec;
};

struct intersecectionIdSetStruct {
    set <unsigned> intersecIdsSet;
};

struct HotelInfo {
    LatLon coordinates;
    vector<std::pair<std::string, std::string>> tags;
    string hotelName;
};

struct GolfCourseInfo {
    vector <Point> coordinatesXYVec;

    vector<std::pair<std::string, std::string>> tags;
    string GolfCourseName;
};

struct AirportInfo {
    vector <Point> coordinatesXYVec;

    vector<std::pair<std::string, std::string>> tags;
    string airportName;
};

struct RunwayInfo {
    vector <Point> coordinatesXYVec;

    vector<std::pair<std::string, std::string>> tags;
    string runwayName;
};


//----------     UN ORDERED MAPS    ---------------------------

extern unordered_map<string, unsigned> hotelNameToIdMap;

extern unordered_map <unsigned long long, unsigned long long > osmdIdToNodeId_Map;

//map with key: intersection_Name and value: intersection ids vector
extern unordered_map<string, vector<unsigned> > Street_name_to_id_map;
//
//map with key: street id and value: structure holding a vector for unsigned ids
extern unordered_map<unsigned, idVecStruct > Street_id_to_all_intersections_map;

//map with key: street name and value: structure holding a vector for unsigned ids
extern unordered_map<string, idVecStruct > Street_Name_to_all_intersections_map;

//for function 3 maps POI name to all nearest intersection ids
extern unordered_map<string, vector<unsigned> >POI_NameToNearestIntersections;




//--------------------------------------------------------------------------

// ---------------- Vectors ----------------------------------------

// outer vector has street ids as index, each element is vector containing 
// street segment ids of that street
extern vector <idVecStruct> streetIds_streetSegsVector;

// outer vector has street ids as index, each element is the total length of that 
// street as double
extern vector <double> streetIds_streetLenVector;

// outer vector has segment ids as index, each element is streetSegmentInfo 
// data structure of that segment id


extern vector <StreetSegmentInfo> streetSegmentInformationVec;

// outer vector has intersection ids as index, each element is LatLon structure 
// of that intersection

extern vector <LatLon> intersectionPositionVec;

//outer vector has point of interests as index, each element is index of 
//the nearest intersection to that point

extern vector <unsigned> nearestInterIDFromPOIVec;

//outer vector has streetIds as index and each element is the name of the 
//corresponding street

extern vector <const char *> streetNames;

//outer vector has streetIds as index and each element is the name of the 
//corresponding POI

extern vector <const char *> POINames;

// outer vector has intersection id as index, each element is vector containing 
// street segment ids of that intersection

extern vector <idVecStruct> intersectionIds_StreetSegsVector;

struct djKStruct {
    unsigned adj_IntersectionId;
    double travelTimeToAdj;
    unsigned streetIdOfAdj;
    unsigned segmentIdOfAdj;
};

struct adjIntersectionRet {
    unsigned adjInterId_;
    unsigned streetId_;
    unsigned segmentId_;
};

extern unordered_map < unsigned, vector< djKStruct> > djKGraph;

extern unordered_map<unsigned, int> interId_to_Parent_Inter_Id;
extern unordered_map<unsigned, int> interId_to_SegId_Parent_Inter_Id;



extern unordered_map<unsigned, int> interId_to_Parent_Inter_Id1;
extern unordered_map<unsigned, int> interId_to_SegId_Parent_Inter_Id1;


//key: single pair of 2 intersection ids and value is their connected seg ID
extern map < pair <unsigned, unsigned>, unsigned > twoIntersections_Conn_SegID;

extern vector <HotelInfo> HotelPlots;
extern vector <GolfCourseInfo> GolfCoursePlots;
extern vector <AirportInfo> AirportPlots;
extern vector <RunwayInfo> RunwayPlots;

extern vector <unsigned> draw_Buildings;
extern vector <unsigned> draw_Parks;
extern vector <unsigned> draw_River;

extern string mapName;





#endif /* DATASTRUCTS_H */

