
#include <queue>

#define pairOfAdjId_traveTime pair<unsigned, double>

#include <list>
#include <unordered_map>
#include "graphics.h"

#include "m3.h"

class comparisonClass {
public:

    bool operator()(pairOfAdjId_traveTime &p1, pairOfAdjId_traveTime &p2) {
        return (p1.second > p2.second);
    }
};

double findHeuristic(unsigned interId, unsigned targetId) {

    //cout << "max Sppedd: " << maxSpeed << endl;
    LatLon interPos1, interPos2;
    interPos1 = getIntersectionPosition(interId);
    interPos2 = getIntersectionPosition(targetId);

    double interToTargetDist = find_distance_squared_between_two_points(interPos1, interPos2);
    double newVal = sqrt(interToTargetDist);
    double timeToTarget = newVal / 100.0;

    //lessen the impact!!
    return (timeToTarget * 0.4);





}

unsigned segId_Between_two_Intersections1(unsigned intersection_id1, unsigned intersection_id2) {

    //Missing out the possibilty of the other segments 

    //vect1 will hold street_segments_ids of intersection 1
    vector<unsigned> vect1;

    vect1 = find_intersection_street_segments(intersection_id1);

    //temporary object
    StreetSegmentInfo tmpInfo;

    //looping through vect1  
    for (unsigned i = 0; i < vect1.size(); i++) {

        // reading each segment ids' Info_structure one by one
        tmpInfo = streetSegmentInformationVec[vect1[i]];

        //if the from of intersection 1 is same as of segment and the to of seg is same as intersection 2, 
        //both intersections are directly connected and {oneway won't matter}
        if (tmpInfo.from == intersection_id1 && tmpInfo.to == intersection_id2) {
            return vect1[i];
        }

        //if it's required to go in other direction, check: 
        if (tmpInfo.from == intersection_id2 && tmpInfo.to == intersection_id1) {
            //checking if seg is 1 way and the start point of the seg isn't equal
            //to starting intersection then you can't go this way

            if (tmpInfo.oneWay == true && tmpInfo.from != intersection_id1) {
                //we already made sure this condition won't be true
                //if the segment is double way then you can go this way
                //cout << "1. segId finder false reached\n";


            } else {
                return vect1[i];
            }
        }

    }

}


//return list by ref that has the retraced back path from target to src

vector<unsigned> reTracePath(unsigned startInter, unsigned targetInter, const vector <int>& interId_To_Parent_InterID_Vec) {

    unsigned curParent;
    vector <unsigned> myVec;
    myVec.push_back(targetInter); //put the target Inter at end of vector

    //loop to retrace the path
    do {
        curParent = interId_To_Parent_InterID_Vec[targetInter];
        //        curParent = interId_to_Parent_Inter_Id.at(targetInter);

        myVec.insert(myVec.begin(), curParent);
        targetInter = curParent;

    } while (curParent != startInter);


    return myVec;

}

vector<unsigned> reTracePath_1(unsigned startInter, unsigned targetInter) {

    unsigned curParent;
    vector <unsigned> myVec;

    myVec.push_back(targetInter); //put the target Inter at end of vector

    //loop to retrace the path
    //    do {
    //
    //
    //    } 
    while (curParent != startInter) {

        curParent = interId_to_Parent_Inter_Id1.at(targetInter);

        myVec.insert(myVec.begin(), curParent);
        targetInter = curParent;

    }


    return myVec;

}



// Returns a path (route) between the start intersection and the end 
// intersection, if one exists. If no path exists, this routine returns 
// an empty (size == 0) vector. If more than one path exists, the path 
// with the shortest travel time is returned. The path is returned as a vector 
// of street segment ids; traversing these street segments, in the given order,
// would take one from the start to the end intersection.

struct neighbourInfo {
    //unsigned neighbourId;
    double nodeValue;
    bool offSetAdded;
};

std::vector<unsigned> find_path_between_intersections(unsigned
        intersect_id_start, unsigned intersect_id_end) {

    vector <int> interId_To_Parent_InterIDVec(numOfIntersections, 0);
    vector <int> interId_To_SegIdParent_IDVec(numOfIntersections, 0);

    //check the adjacent intersections!!!
    //going to draw the adjacent intersections of both start and end node
    //keeps the min travele time pair on top of the heap using comparison class as comparator
    priority_queue < pairOfAdjId_traveTime, vector < pairOfAdjId_traveTime >, comparisonClass > PQ;

    set<pair<double, unsigned>> mySet; //keeping the node value first so min is first


    //created vector with total num Of intersections and INTMAX as initial value
    //keeps track of node values
    vector <double> distRefVec(numOfIntersections, DBL_MAX);

    distRefVec[intersect_id_start] = 0.0;

    interId_to_Parent_Inter_Id[intersect_id_start] = -1;

    interId_To_Parent_InterIDVec[intersect_id_start] = -1;

    unsigned adjInterId, adjacentSegId;



    //this loop just pushes the adjacent nodes of the start intersection into heap with their values    

    unsigned intersections_count = getIntersectionStreetSegmentCount(intersect_id_start);

    //cout << "intersection count: " << intersections_count << endl;
    // Have to check for a 1 way road 
    unsigned segId, streetId;



    for (unsigned i = 0; i < intersections_count; i++) {
        //cout << "3here\n";
        
        
        unsigned segId = getIntersectionStreetSegment(intersect_id_start, i);

        StreetSegmentInfo streetSeg_struct = streetSegmentInformationVec[segId];
        adjIntersectionRet fillStr;
        //segId is street segment id for that intersection

        if (streetSeg_struct.from == intersect_id_start) {
            //i.e adjacent intersection is a "to", hence, connected 
            //Using the street segment id to get all the info
            // Have to check for street segment connections and 1-ways

            // 
            //push in the street id in it make a strtucutre return vector
            pair<unsigned, double> interToPushInPair;

            //fillStr.adjInterId_ = streetSeg_struct.to;
            interToPushInPair.first = streetSeg_struct.to;
            interToPushInPair.second = find_street_segment_travel_time(segId);
            //          PQ.push(interToPushInPair);
            distRefVec[interToPushInPair.first] = interToPushInPair.second;

            PQ.push(interToPushInPair);

            interId_To_Parent_InterIDVec[interToPushInPair.first] = intersect_id_start;

            //  cout << "4here\n";
            interId_To_SegIdParent_IDVec[interToPushInPair.first] = segId;
            //cout << "5here\n";


        }//For the case if the from & to are flipped but the road is 2-way

        else if (streetSeg_struct.to == intersect_id_start) {
            //Segment may start from the other end but if it is 
            // !1-way, still adjacent 
            if (streetSeg_struct.oneWay == true) {


            } else {

                //unsigned segId = getIntersectionStreetSegment(intersect_id_start, i);
                //Using the street segment id to get all the info
                // Have to check for street segment connections and 1-ways
                //StreetSegmentInfo streetSeg_struct = streetSegmentInformationVec[segId];


                pair<unsigned, double> interToPushInPair;


                interToPushInPair.first = streetSeg_struct.from;

                interToPushInPair.second = find_street_segment_travel_time(segId);

                //                PQ.push(interToPushInPair);
                distRefVec[interToPushInPair.first] = interToPushInPair.second;

                PQ.push(interToPushInPair);

                interId_To_Parent_InterIDVec[interToPushInPair.first] = intersect_id_start;

                interId_To_SegIdParent_IDVec[interToPushInPair.first] = segId;

            }
        }



    }



    while (!PQ.empty()) {


        pair <unsigned, double> pairFromHeap = PQ.top();

        unsigned interIdFromHeap = pairFromHeap.first;

        double adjIdTravelTimeFromHeap = pairFromHeap.second;


        PQ.pop(); // remove the top element



        //now process the neighbour intersections of the pair id


        if (interIdFromHeap == intersect_id_end && adjIdTravelTimeFromHeap != DBL_MAX) {

            // cout << "found the total paht now retracing\n";
            //found target node
            vector<unsigned> tracedBackPath;

            tracedBackPath = reTracePath(intersect_id_start, interIdFromHeap, interId_To_Parent_InterIDVec);

            pair <unsigned, unsigned> myP;

            vector <unsigned> retVec;
            vector <unsigned> retVec1;

            vector <unsigned> retVec3;

            for (unsigned i = 0; i < tracedBackPath.size() - 1; i++) {

                myP.first = tracedBackPath[i];

                myP.second = tracedBackPath[i + 1];

                //1st retrace method-----------------------
                //using the retracing from the parent segId Map giving the intersection of next index
                retVec.push_back(interId_To_SegIdParent_IDVec[(myP.second)]);


                //                // 3rd retrace method --------------------------
                auto it = segId_Between_two_Intersections1(myP.first, myP.second);
                retVec3.push_back(it);

            }
            //
            double travelTime, travelTime2, travelTime3;
            travelTime = compute_path_travel_time(retVec);
            //travelTime2 = compute_path_travel_time(retVec1);
            travelTime3 = compute_path_travel_time(retVec3);



            //   cout << "----------------------\n";
            //            cout << "\ntarget time of retVec: " << travelTime << endl;
            //            //cout << "target time of travelTime2: " << travelTime2 << endl;
            //            cout << "target time of travelTime3: " << travelTime3 << endl;
            //            //  cout << "----------------------\n";


            if (travelTime < travelTime3) {
                //                cout << "returning retVec\n";
                return retVec;
            } else {
                //                cout << "returning retVec3\n";
                return retVec3;
            }

        }
        //else keep on searching and if you reach the end of heap and then hit the target that will have inf then no path



        pair <unsigned, unsigned> interIdsPair;
        //segment 1 is from parent of the current node to the current node 
        //get street id1 from segid 1

        //grabbing the parent intersecion of the id you just popped from the heap


        //getting the segment id of current intersection parent's  &  current intersection
        //getting the parent of popped intersection
        interIdsPair.first = interId_To_Parent_InterIDVec[(interIdFromHeap)]; //interId_to_Parent_Inter_Id.at(interIdFromHeap); //got A

        //the id of popped intersection 
        interIdsPair.second = interIdFromHeap; //got B

        //getting seg id b/w the parent and the node popped node
        unsigned segId1_2 = segId_Between_two_Intersections1(interIdsPair.first, interIdsPair.second);
        StreetSegmentInfo segInfo1 = streetSegmentInformationVec[segId1_2];
        unsigned streetIdFromSegId1 = segInfo1.streetID;





        unsigned parentOfcurInter = interIdsPair.first; //interId_to_Parent_Inter_Id.at(interIdFromHeap);



        auto parentVec = djKGraph.at(parentOfcurInter);
        unsigned streetId1;
        //got parent vector want to get the street id of parent->current intersection
        for (unsigned a = 0; a < parentVec.size(); a++) {
            if (parentVec[a].adj_IntersectionId == interIdFromHeap) {
                streetId1 = parentVec[a].streetIdOfAdj;

            }

        }


        auto it2 = djKGraph.find(interIdFromHeap);



        if (it2 != djKGraph.end()) {//safe check to avoid exception throw from djk in case no adjacent exits for an intersection like 3116 in toronto


            //get the adjacent intersections of the popped intersection and calculate the values of them
            for (unsigned i = 0; i < djKGraph.at(interIdFromHeap).size(); i++) {


                //got the ith negigbour of intersection gotten from heap
                auto curGraphPair = djKGraph.at(interIdFromHeap)[i];

                unsigned adjacentSegId = curGraphPair.segmentIdOfAdj;

                unsigned adjInterId = curGraphPair.adj_IntersectionId; // C

                double adjTravelTime = curGraphPair.travelTimeToAdj;

                unsigned streetId2 = curGraphPair.streetIdOfAdj;



                //        double hValue = findHeuristic(adjInterId, intersect_id_end);

                double distFromRefVecofAdj = distRefVec[adjInterId]; //need to be of the main node you are processing from 

                double distFromRefVecofMainNode = distRefVec[interIdFromHeap];


                unsigned segId2 = segId_Between_two_Intersections1(interIdFromHeap, adjInterId);


                StreetSegmentInfo segInfo2 = streetSegmentInformationVec[segId2];


                unsigned streetIdFromSegId2 = segInfo2.streetID;

                //fist 2 are g costs and then add h value
                double newVal = distFromRefVecofMainNode + adjTravelTime; // + hValue;
                double newVaue_Old_Method = distFromRefVecofMainNode + adjTravelTime; // + hValue;


                if (streetIdFromSegId1 != streetIdFromSegId2) {
                    newVaue_Old_Method = newVaue_Old_Method + 0.25;
                } else {

                }


                if (streetId1 != streetId2) {

                    newVal = newVal + 0.25; //\\\(15.0 / 60.0);

                } else {
                    //didn't add offset
                }

                //search thru refVec, get the value of adjInterId in their if its less than already present

                //need to account for 15s offset before doing this
                if (newVaue_Old_Method < newVal) {
                    newVal = newVaue_Old_Method;
                }


                if (newVal < distFromRefVecofAdj) {

                    //update the value in the ref Vector
                    distRefVec[adjInterId] = newVal;
                    PQ.push(make_pair(adjInterId, newVal));

                    //setting the parent of the current processed adjacent intersection to outter heap processed inter id
                    //  interId_to_Parent_Inter_Id[adjInterId] = interIdFromHeap;

                    //interId_to_SegId_Parent_Inter_Id[adjInterId] = adjacentSegId;

                    interId_To_Parent_InterIDVec[adjInterId] = interIdFromHeap;

                    interId_To_SegIdParent_IDVec[adjInterId] = adjacentSegId;

                } else {


                }



            }




        }






    }

    //we checked all inter ids pair from heap and couldn't find the target with non inf so that means path doesn't exists!!!!!!!!!
    //put the empty vector of segids to return in this case

    //    cout << "path not found heap got empty\n";
    vector <unsigned> empVec;
    //cout << "no path found\n";
    return empVec;


}
//
//std::vector<unsigned> find_path_m4(unsigned &intersect_id_start, set <unsigned>& dropOffIntersSet, vector<bool>&didPickupVec) {
//
//
//
//
//
//
//
//    vector <int> interId_To_Parent_InterIDVec(numOfIntersections, 0);
//    vector <int> interId_To_SegIdParent_IDVec(numOfIntersections, 0);
//
//    //check the adjacent intersections!!!
//    //going to draw the adjacent intersections of both start and end node
//    //keeps the min travele time pair on top of the heap using comparison class as comparator
//    priority_queue < pairOfAdjId_traveTime, vector < pairOfAdjId_traveTime >, comparisonClass > PQ;
//
//
//
//
//    //created vector with total num Of intersections and INTMAX as initial value
//    //keeps track of node values
//    vector <double> distRefVec(numOfIntersections, DBL_MAX);
//
//    distRefVec[intersect_id_start] = 0.0;
//
//    interId_to_Parent_Inter_Id[intersect_id_start] = -1;
//
//    interId_To_Parent_InterIDVec[intersect_id_start] = -1;
//
//    unsigned adjInterId, adjacentSegId;
//
//
//
//    //this loop just pushes the adjacent nodes of the start intersection into heap with their values    
//
//    unsigned intersections_count = getIntersectionStreetSegmentCount(intersect_id_start);
//
//    //cout << "intersection count: " << intersections_count << endl;
//    // Have to check for a 1 way road 
//    unsigned segId, streetId;
//
//
//
//    for (unsigned i = 0; i < intersections_count; i++) {
//        //cout << "3here\n";
//        unsigned segId = getIntersectionStreetSegment(intersect_id_start, i);
//
//        StreetSegmentInfo streetSeg_struct = streetSegmentInformationVec[segId];
//        adjIntersectionRet fillStr;
//        //segId is street segment id for that intersection
//
//        if (streetSeg_struct.from == intersect_id_start) {
//            //i.e adjacent intersection is a "to", hence, connected 
//            //Using the street segment id to get all the info
//            // Have to check for street segment connections and 1-ways
//
//            // 
//            //push in the street id in it make a strtucutre return vector
//            pair<unsigned, double> interToPushInPair;
//
//            //fillStr.adjInterId_ = streetSeg_struct.to;
//            interToPushInPair.first = streetSeg_struct.to;
//            interToPushInPair.second = find_street_segment_travel_time(segId);
//            //          PQ.push(interToPushInPair);
//            distRefVec[interToPushInPair.first] = interToPushInPair.second;
//
//            PQ.push(interToPushInPair);
//
//            interId_To_Parent_InterIDVec[interToPushInPair.first] = intersect_id_start;
//
//            //  cout << "4here\n";
//            interId_To_SegIdParent_IDVec[interToPushInPair.first] = segId;
//            //cout << "5here\n";
//
//
//        }//For the case if the from & to are flipped but the road is 2-way
//
//        else if (streetSeg_struct.to == intersect_id_start) {
//            //Segment may start from the other end but if it is 
//            // !1-way, still adjacent 
//            if (streetSeg_struct.oneWay == true) {
//
//
//            } else {
//
//                //unsigned segId = getIntersectionStreetSegment(intersect_id_start, i);
//                //Using the street segment id to get all the info
//                // Have to check for street segment connections and 1-ways
//                //StreetSegmentInfo streetSeg_struct = streetSegmentInformationVec[segId];
//
//
//                pair<unsigned, double> interToPushInPair;
//
//
//                interToPushInPair.first = streetSeg_struct.from;
//
//                interToPushInPair.second = find_street_segment_travel_time(segId);
//
//                //                PQ.push(interToPushInPair);
//                distRefVec[interToPushInPair.first] = interToPushInPair.second;
//
//                PQ.push(interToPushInPair);
//
//                interId_To_Parent_InterIDVec[interToPushInPair.first] = intersect_id_start;
//
//                interId_To_SegIdParent_IDVec[interToPushInPair.first] = segId;
//
//            }
//        }
//
//
//
//    }
//
//
//    vector <unsigned> segIdsJoinedVec, intersectionIds;
//    while (!PQ.empty()) {
//
//
//        pair <unsigned, double> pairFromHeap = PQ.top();
//
//        unsigned interIdFromHeap = pairFromHeap.first;
//        cout << "interid From Heap: " << interIdFromHeap << endl;
//
//        double adjIdTravelTimeFromHeap = pairFromHeap.second;
//
//
//        PQ.pop(); // remove the top element //did this only when required in the checks below
//        //
//        //
//        //extern unordered_map <unsigned, set<unsigned> > pickupToDropOffMap;
//        //extern unordered_map <unsigned, set<unsigned> > dropOffToPickupMap;
//        //
//        //extern set<unsigned> totalPickups; //all the unique pickups intersections
//        //extern vector<unsigned> dropOffIdsVec;
//        //extern vector<unsigned> pickupsDone;
//        //now process the neighbour intersections of the pair id
//
//        cout << "after popping from heap:\n";
//        cout << "checking for pickup first\n";
//
//        unordered_map<unsigned, set<unsigned> >::iterator iter = pickupToDropOffMap.find(interIdFromHeap);
//
//        if (iter != pickupToDropOffMap.end()) {
//            //means its a pickup 
//            //check if you haven't picked it from didPickupVector
//            if (didPickupVec[interIdFromHeap] == false) {
//                cout << "point is a pickup and not already visited:\n";
//                cout << "size of pickupsDone Vec before adding: " << pickupsDone.size() << endl;
//                pickupsDone.push_back(interIdFromHeap); //adding this to picked up vector
//                cout << "size of pickupsDone Vec after adding: " << pickupsDone.size() << endl;
//
//
//                didPickupVec[interIdFromHeap] = true;
//                //PQ.pop(); //remove this from heap
//
//                //call retrace to this point
//
//
//                //make this start inter for next time
//                //segIdsJoinedVec, intersectionIds;
//                intersectionIds = reTracePath(intersect_id_start, interIdFromHeap, interId_To_Parent_InterIDVec);
//                for (unsigned j = 0; j < intersectionIds.size() - 1; j++) {
//                    totalPathForM4.push_back(interId_To_SegIdParent_IDVec[intersectionIds[j + 1]]);
//                }
//                intersect_id_start = interIdFromHeap;
//                vector <unsigned> emptyVec;
//                //all the stuff to be changed is global or by ref so just return emp vec
//                return emptyVec;
//
//            } else {
//                cout << "point was already picked up so pushing back in heap:\n";
//                //PQ.push(pairFromHeap);
//            }
//
//        }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//        unordered_map<unsigned, set<unsigned> >::iterator itDropOffCheck = dropOffToPickupMap.find(interIdFromHeap);
//        //checking if the intersection that came out is dropOff of any of the dropOff reqd to visit from our pickups done
//        if (itDropOffCheck != dropOffToPickupMap.end()) {
//            cout << "dropOff check passed:\n";
//
//            if (pickupsDone.size() != 0) { //have some packages picked up check if the dropOff is of one of them
//                //need to check if the drop off is for atleast one of the pickups
//                //might be possible if the dropOff is of multiple pickups and you haven't picked up all the packages for it!!!!! should we 
//                //visit this dropOFF once we have all the packages whose drop off is this one or not?
//                cout << "pickupsDone size non zero:\n";
//                //get the pickup ids set for this dropOff from the dropOffToPickupMap and then take each one of the id in it and compare it with
//                // with the pickupsDone vector?
//                set<unsigned> pickupsFromMap = (itDropOffCheck)->second; //dropOffToPickupMap.at(interIdFromHeap);
//                unsigned pickUpReqdSize = pickupsFromMap.size();
//                cout << "pickUpReqdSize: " << pickUpReqdSize << endl;
//
//                unsigned pickupsInourVec = 0;
//
//                set<unsigned>::iterator it;
//                //before delivering to this particular dropOff we must have the matching pickups in our own vector
//                for (it = pickupsFromMap.begin(); it != pickupsFromMap.end(); it++) {
//
//                    unsigned curPickupId = *it;
//                    cout << "curPickupId: " << curPickupId << endl;
//                    if (didPickupVec[curPickupId] == true) {
//                        pickupsInourVec++;
//
//                    }
//                    cout << "pickupsInourVec: " << pickupsInourVec << endl;
//
//                    //must check if its a dropff of how many pickups in the map
//                    //make a map with key dropOff and value is the count that shows how many total pickups have
//                    //this as dropOff and how many currently have been picked up for this dropOff then from dropOffIdsVec delete thant
//                    //many instances of it, and from map reset the second count to zero and make first the result of subtracting 
//                    //second count from first!
//                    //for this map set the first count variable in the callee and modify the second count inside this fxn, 
//                    //when you do a pickup then check its dropOff and ++ that in the map!,/cdipv
//
//                }
//                if (pickupsInourVec == pickUpReqdSize) {
//                    //PQ.pop();
//                    auto itToDel = dropOffIntersSet.find(interIdFromHeap);
//                    cout << "dropOffIntersSet.size before removal of dropOff: " << dropOffIntersSet.size() << endl;
//                    dropOffIntersSet.erase(itToDel); //erasing the thing popped from the heap ie dropOff here from the main dropOffIdsSet
//                    //change the start intersection to this
//                    cout << "dropOffIntersSet.size after removal of dropOff: " << dropOffIntersSet.size() << endl;
//                    //call retrace path and append it to a global previous path
//                    intersectionIds = reTracePath(intersect_id_start, interIdFromHeap, interId_To_Parent_InterIDVec);
//
//                    for (unsigned j = 0; j < intersectionIds.size() - 1; j++) {
//                        totalPathForM4.push_back(interId_To_SegIdParent_IDVec[intersectionIds[j + 1]]);
//                    }
//                    //got the path upto this point from the start and adding it to global path needed
//                    //totalPathForM4.insert(totalPathForM4.end(), segIdsJoinedVec.begin(), segIdsJoinedVec, end());
//
//                    intersect_id_start = interIdFromHeap;
//
//                    vector <unsigned> emptyVec;
//                    //all the stuff to be changed is global or by ref so just return emp vec
//                    return emptyVec;
//                    //we have all the pickups required by this dropOff so make a path to it,remove this dropOff from the set
//                } else {//don't have all the pickups required skip this intersection ie push it back in the heap for popped again later
//
//                    PQ.push(pairFromHeap); //Note::   or do the PQ.pop only if the condition is met
//                }
//
//                //call retrace with start and this dropOff as endpoint and return the segments
//            } else {
//                cout << "pickupDone is empty:\n";
//            }
//
//
//        }
//        cout << "finished checking dropOff now going to check pickup\n";
//        // Finished checking if the thing was a dropOff 
//
//        //-------------------------------------------------------
//
//        //check for if the thing is a pickup
//
//
//
//
//
//        //        if (interIdFromHeap == intersect_id_end && adjIdTravelTimeFromHeap != DBL_MAX) {
//        //
//        //            // cout << "found the total paht now retracing\n";
//        //            //found target node
//        //            vector<unsigned> tracedBackPath;
//        //
//        //            tracedBackPath = reTracePath(intersect_id_start, interIdFromHeap, interId_To_Parent_InterIDVec);
//        //
//        //            pair <unsigned, unsigned> myP;
//        //
//        //            vector <unsigned> retVec;
//        //            vector <unsigned> retVec1;
//        //
//        //            vector <unsigned> retVec3;
//        //
//        //            for (unsigned i = 0; i < tracedBackPath.size() - 1; i++) {
//        //
//        //                myP.first = tracedBackPath[i];
//        //
//        //                myP.second = tracedBackPath[i + 1];
//        //
//        //                //1st retrace method-----------------------
//        //                //using the retracing from the parent segId Map giving the intersection of next index
//        //                retVec.push_back(interId_To_SegIdParent_IDVec[(myP.second)]);
//        //
//        //
//        //                //                // 3rd retrace method --------------------------
//        //                auto it = segId_Between_two_Intersections1(myP.first, myP.second);
//        //                retVec3.push_back(it);
//        //
//        //            }
//        //            //
//        //            double travelTime, travelTime2, travelTime3;
//        //            travelTime = compute_path_travel_time(retVec);
//        //
//        //            travelTime3 = compute_path_travel_time(retVec3);
//        //
//        //
//        //
//        //
//        //            if (travelTime < travelTime3) {
//        //                //                cout << "returning retVec\n";
//        //                return retVec;
//        //            } else {
//        //                //                cout << "returning retVec3\n";
//        //                return retVec3;
//        //            }
//        //
//        //        }
//
//
//
//
//
//
//        //else keep on searching and if you reach the end of heap and then hit the target that will have inf then no path
//
//
//        cout << "no checks passed continue processing:\n";
//        pair <unsigned, unsigned> interIdsPair;
//        //segment 1 is from parent of the current node to the current node 
//        //get street id1 from segid 1
//
//        //grabbing the parent intersecion of the id you just popped from the heap
//
//
//        //getting the segment id of current intersection parent's  &  current intersection
//        //getting the parent of popped intersection
//        interIdsPair.first = interId_To_Parent_InterIDVec[(interIdFromHeap)]; //interId_to_Parent_Inter_Id.at(interIdFromHeap); //got A
//
//        //the id of popped intersection 
//        interIdsPair.second = interIdFromHeap; //got B
//
//        //getting seg id b/w the parent and the node popped node
//        unsigned segId1_2 = segId_Between_two_Intersections1(interIdsPair.first, interIdsPair.second);
//        StreetSegmentInfo segInfo1 = streetSegmentInformationVec[segId1_2];
//        unsigned streetIdFromSegId1 = segInfo1.streetID;
//
//
//
//
//
//        unsigned parentOfcurInter = interIdsPair.first; //interId_to_Parent_Inter_Id.at(interIdFromHeap);
//
//
//
//        auto parentVec = djKGraph.at(parentOfcurInter);
//        unsigned streetId1;
//        //got parent vector want to get the street id of parent->current intersection
//        for (unsigned a = 0; a < parentVec.size(); a++) {
//            if (parentVec[a].adj_IntersectionId == interIdFromHeap) {
//                streetId1 = parentVec[a].streetIdOfAdj;
//
//            }
//
//        }
//
//
//        auto it2 = djKGraph.find(interIdFromHeap);
//
//
//
//        if (it2 != djKGraph.end()) {//safe check to avoid exception throw from djk in case no adjacent exits for an intersection like 3116 in toronto
//
//
//            //get the adjacent intersections of the popped intersection and calculate the values of them
//            for (unsigned i = 0; i < djKGraph.at(interIdFromHeap).size(); i++) {
//
//
//                //got the ith negigbour of intersection gotten from heap
//                auto curGraphPair = djKGraph.at(interIdFromHeap)[i];
//
//                unsigned adjacentSegId = curGraphPair.segmentIdOfAdj;
//
//                unsigned adjInterId = curGraphPair.adj_IntersectionId; // C
//
//                double adjTravelTime = curGraphPair.travelTimeToAdj;
//
//                unsigned streetId2 = curGraphPair.streetIdOfAdj;
//
//
//
//                //        double hValue = findHeuristic(adjInterId, intersect_id_end);
//
//                double distFromRefVecofAdj = distRefVec[adjInterId]; //need to be of the main node you are processing from 
//
//                double distFromRefVecofMainNode = distRefVec[interIdFromHeap];
//
//
//                unsigned segId2 = segId_Between_two_Intersections1(interIdFromHeap, adjInterId);
//
//
//                StreetSegmentInfo segInfo2 = streetSegmentInformationVec[segId2];
//
//
//                unsigned streetIdFromSegId2 = segInfo2.streetID;
//
//                //fist 2 are g costs and then add h value
//                double newVal = distFromRefVecofMainNode + adjTravelTime; // + hValue;
//                double newVaue_Old_Method = distFromRefVecofMainNode + adjTravelTime; // + hValue;
//
//
//                if (streetIdFromSegId1 != streetIdFromSegId2) {
//                    newVaue_Old_Method = newVaue_Old_Method + 0.25;
//                } else {
//
//                }
//
//
//                if (streetId1 != streetId2) {
//
//                    newVal = newVal + 0.25; //\\\(15.0 / 60.0);
//
//                } else {
//                    //didn't add offset
//                }
//
//                //search thru refVec, get the value of adjInterId in their if its less than already present
//
//                //need to account for 15s offset before doing this
//                if (newVaue_Old_Method < newVal) {
//                    newVal = newVaue_Old_Method;
//                }
//
//
//                if (newVal < distFromRefVecofAdj) {
//
//                    //update the value in the ref Vector
//                    distRefVec[adjInterId] = newVal;
//                    PQ.push(make_pair(adjInterId, newVal));
//
//                    //setting the parent of the current processed adjacent intersection to outter heap processed inter id
//                    //  interId_to_Parent_Inter_Id[adjInterId] = interIdFromHeap;
//
//                    //interId_to_SegId_Parent_Inter_Id[adjInterId] = adjacentSegId;
//
//                    interId_To_Parent_InterIDVec[adjInterId] = interIdFromHeap;
//
//                    interId_To_SegIdParent_IDVec[adjInterId] = adjacentSegId;
//
//                } else {
//
//
//                }
//
//
//
//            }
//
//
//
//
//        }
//
//
//
//
//
//
//    }
//
//    //we checked all inter ids pair from heap and couldn't find the target with non inf so that means path doesn't exists!!!!!!!!!
//    //put the empty vector of segids to return in this case
//
//    //    cout << "path not found heap got empty\n";
//    vector <unsigned> empVec;
//    cout << "no path found\n";
//    return empVec;
//
//
//
//
//
//}
//
//
//
//
//
//
//
//






// Returns the time required to travel along the path specified. The path
// is passed in as a vector of street segment ids, and this function can 
// assume the vector either forms a legal path or has size == 0.
// The travel time is the sum of the length/speed-limit of each street 
// segment, plus 15 seconds per turn implied by the path. A turn occurs
// when two consecutive street segments have different street names.

double compute_path_travel_time(const std::vector<unsigned>& path) {

    double path_travel_time = 0.0;
    unsigned path_size = path.size();
    double offset = 15.0 / 60.0;

    // Check if the path is not empty vector 
    if (path.empty() == false) {//Means not empty 

        //Path has street seg ids
        for (unsigned i = 0; i < path_size; i++) {

            unsigned seg_id = path[i];

            double seg_travel_time = (find_street_segment_travel_time(seg_id));

            // Check if the 2nd segment belongs to another road
            // indexing runs 1 less than the length
            if ((i + 1) < path_size) {

                unsigned seg_id2 = path[i + 1];
                if (streetSegmentInformationVec[seg_id].streetID != streetSegmentInformationVec[seg_id2].streetID) {
                    //Means the seg are from different streets
                    // Add extra 15 sec to the travel time 
                    path_travel_time += (offset + seg_travel_time);
                } else {

                    path_travel_time += seg_travel_time;
                }


            }// When at final index, just add the segment time
            else {

                path_travel_time += seg_travel_time;
            }



        }

        return path_travel_time;

    } else {
        //Path is empty or doesn't exist
        return 0;
    }




}


// Returns the shortest travel time path (vector of street segments) from 
// the start intersection to a point of interest with the specified name.
// If no such path exists, returns an empty (size == 0) vector.

std::vector<unsigned> find_path_to_point_of_interest(unsigned
        intersect_id_start, std::string point_of_interest_name) {


    vector<unsigned> nearIntersectionsVec;

    for (unsigned i = 0; i < numOfPOI; i++) {

        string POIName = getPointOfInterestName(i);
        if (POIName == point_of_interest_name) {
            unsigned intersectionIndex = find_closest_intersection(getPointOfInterestPosition(i));


            nearIntersectionsVec.push_back(intersectionIndex);



        }
        //nearestInterIDFromPOIVec.push_back(intersectionIndex);
        //Generate vector that holds all streetNames in the current map
        //POINames.push_back(POIName.c_str());
    }






    //auto it = POI_NameToNearestIntersections.find(point_of_interest_name);
    if (nearIntersectionsVec.size() != 0) {


        //check the adjacent intersections!!!
        //going to draw the adjacent intersections of both start and end node
        //keeps the min travele time pair on top of the heap using comparison class as comparator
        priority_queue < pairOfAdjId_traveTime, vector < pairOfAdjId_traveTime >, comparisonClass > PQ;



        //created vector with total num Of intersections and INTMAX as initial value
        //keeps track of node values
        vector <double> distRefVec(numOfIntersections, DBL_MAX);

        distRefVec[intersect_id_start] = 0.0;
        interId_to_Parent_Inter_Id1[intersect_id_start] = -1;


        unsigned adjInterId, adjacentSegId;
        //this loop just pushes the adjacent nodes of the start intersection into heap with their values
        for (unsigned i = 0; i < djKGraph [intersect_id_start].size(); i++) {
            //cout << "src neighbouring process started\n";

            auto curGraphPair = djKGraph [intersect_id_start][i];

            adjInterId = curGraphPair.adj_IntersectionId;

            //segment that leads to neighbour from start inter id
            adjacentSegId = curGraphPair.segmentIdOfAdj;

            //unsigned adjacentSegid1_2 = segId_Between_two_Intersections(interId,adjInterId);
            double adjTravelTime = curGraphPair.travelTimeToAdj;


            //double hValue = findHeuristic(adjInterId, intersect_id_end);

            //        double updatedValue = adjTravelTime + hValue;
            distRefVec[adjInterId] = adjTravelTime;

            PQ.push(make_pair(adjInterId, adjTravelTime));

            interId_to_Parent_Inter_Id1[adjInterId] = intersect_id_start;

            interId_to_SegId_Parent_Inter_Id1[adjInterId] = adjacentSegId;


        }

        //we have inserted some initial adjacent intersections in heap from source id
        //now that we processed all adjacent intersections from source start processing
        //the min ids from heap

        while (!PQ.empty()) {


            pair <unsigned, double> pairFromHeap = PQ.top();

            unsigned interIdFromHeap = pairFromHeap.first;

            double adjIdTravelTimeFromHeap = pairFromHeap.second;


            PQ.pop(); // remove the top element



            for (unsigned j = 0; j < nearIntersectionsVec.size(); j++) {
                // cout <<"checking the popped node with vec\n";
                if (interIdFromHeap == nearIntersectionsVec[j] && adjIdTravelTimeFromHeap != DBL_MAX) {


                    //found target node
                    vector<unsigned> tracedBackPath;

                    tracedBackPath = reTracePath_1(intersect_id_start, interIdFromHeap);

                    pair <unsigned, unsigned> myP;

                    vector <unsigned> retVec;
                    vector <unsigned> retVec1;

                    vector <unsigned> retVec3;

                    for (unsigned i = 0; i < tracedBackPath.size() - 1; i++) {

                        myP.first = tracedBackPath[i];

                        myP.second = tracedBackPath[i + 1];

                        //1st retrace method-----------------------
                        //using the retracing from the parent segId Map giving the intersection of next index
                        retVec.push_back(interId_to_SegId_Parent_Inter_Id1.at(myP.second));


                        //                // 3rd retrace method --------------------------
                        auto it = segId_Between_two_Intersections1(myP.first, myP.second);
                        retVec3.push_back(it);

                    }
                    //
                    double travelTime, travelTime3;

                    travelTime = compute_path_travel_time(retVec);
                    //travelTime2 = compute_path_travel_time(retVec1);
                    travelTime3 = compute_path_travel_time(retVec3);





                    if (travelTime < travelTime3) {
                        return retVec;
                    } else {
                        return retVec3;
                    }

                }

            }

            //now process the neighbour intersections of the pair id


            //else keep on searching and if you reach the end of heap and then hit the target that will have inf then no path



            pair <unsigned, unsigned> interIdsPair;
            //segment 1 is from parent of the current node to the current node 
            //get street id1 from segid 1

            //grabbing the parent intersecion of the id you just popped from the heap


            //getting the segment id of current intersection parent's  &  current intersection
            //getting the parent of popped intersection
            interIdsPair.first = interId_to_Parent_Inter_Id1.at(interIdFromHeap); //interId_to_Parent_Inter_Id.at(interIdFromHeap); //got A
            //the id of popped intersection 
            interIdsPair.second = interIdFromHeap; //got B

            //getting seg id b/w the parent and the node popped node
            unsigned segId1_2 = segId_Between_two_Intersections1(interIdsPair.first, interIdsPair.second);
            StreetSegmentInfo segInfo1 = streetSegmentInformationVec[segId1_2];
            unsigned streetIdFromSegId1 = segInfo1.streetID;





            unsigned parentOfcurInter = interId_to_Parent_Inter_Id1.at(interIdFromHeap);


            auto parentVec = djKGraph.at(parentOfcurInter);
            unsigned streetId1;
            //got parent vector want to get the street id of parent->current intersection
            for (unsigned a = 0; a < parentVec.size(); a++) {
                if (parentVec[a].adj_IntersectionId == interIdFromHeap) {
                    streetId1 = parentVec[a].streetIdOfAdj;

                }

            }

            auto it2 = djKGraph.find(interIdFromHeap);



            if (it2 != djKGraph.end()) {//safe check to avoid exception throw from djk in case no adjacent exits for an intersection like 3116 in toronto
                //   cout <<"6.h343\n";

                //get the adjacent intersections of the popped intersection and calculate the values of them
                for (unsigned i = 0; i < djKGraph.at(interIdFromHeap).size(); i++) {


                    //got the ith negigbour of intersection gotten from heap
                    auto curGraphPair = djKGraph.at(interIdFromHeap)[i];

                    unsigned adjacentSegId = curGraphPair.segmentIdOfAdj;

                    unsigned adjInterId = curGraphPair.adj_IntersectionId; // C

                    double adjTravelTime = curGraphPair.travelTimeToAdj;

                    unsigned streetId2 = curGraphPair.streetIdOfAdj;




                    double distFromRefVecofAdj = distRefVec[adjInterId]; //need to be of the main node you are processing from 

                    double distFromRefVecofMainNode = distRefVec[interIdFromHeap];


                    unsigned segId2 = segId_Between_two_Intersections1(interIdFromHeap, adjInterId);


                    StreetSegmentInfo segInfo2 = streetSegmentInformationVec[segId2];


                    unsigned streetIdFromSegId2 = segInfo2.streetID;

                    //fist 2 are g costs and then add h value
                    double newVal = distFromRefVecofMainNode + adjTravelTime;
                    double newVaue_Old_Method = distFromRefVecofMainNode + adjTravelTime;


                    if (streetIdFromSegId1 != streetIdFromSegId2) {
                        newVaue_Old_Method = newVaue_Old_Method + 0.25;
                    } else {

                    }


                    if (streetId1 != streetId2) {

                        newVal = newVal + 0.25;

                    } else {
                        //didn't add offset
                    }

                    //search thru refVec, get the value of adjInterId in their if its less than already present

                    //need to account for 15s offset before doing this
                    if (newVaue_Old_Method < newVal) {
                        newVal = newVaue_Old_Method;
                    }


                    //   cout << "7here\n";
                    if (newVal < distFromRefVecofAdj) {

                        //update the value in the ref Vector
                        distRefVec[adjInterId] = newVal;
                        PQ.push(make_pair(adjInterId, newVal));

                        //setting the parent of the current processed adjacent intersection to outter heap processed inter id
                        interId_to_Parent_Inter_Id1[adjInterId] = interIdFromHeap;

                        interId_to_SegId_Parent_Inter_Id1[adjInterId] = adjacentSegId;


                    } else {


                    }



                }




            }



        }
        //  cout << "heap empty\n";





    }


}





//    vector<unsigned> ret;
//    vector<unsigned> temp;
//    double distance = INT_MAX;
//    double tempd; 
//    unsigned intersection_id_end; 
//    //Get LatLon coordinates of starting intersection id
//    
//    LatLon intersectionPosition = intersectionPositionVec[intersect_id_start];
//    //Find closest point of interest to the starting intersection
//    //cout<<"Calling poi function "<<"\n";
//    vector<unsigned> pID = find_all_closest_point_of_interest_by_name(intersectionPosition, point_of_interest_name);
//    //unsigned pointOfInterestID = find_closest_point_of_interest_by_name(intersectionPosition, point_of_interest_name);
//    for(unsigned int i =0 ; i< pID.size(); i++)
//    {
//   //cout<<"POI ID is "<<pointOfInterestID<<"\n"; 
//   // cout<<"POI name is "<<getPointOfInterestName(pID[i])<<"\n";
//    
//       
//    
//    // Get nearest intersection (by ID) to the Point of interest found earlier
//     intersection_id_end = find_closest_intersection(getPointOfInterestPosition(pID[i]));
//   //unsigned intersection_id_end = nearestInterIDFromPOIVec[pointOfInterestID];
//    //cout<<"Intersection id end is "<<intersection_id_end<<"\n";
//
//    temp = find_path_between_intersections(intersect_id_start, intersection_id_end);
//    tempd = compute_path_travel_time(temp);
//    
// 
//   
//    
//      //  cout<<"current travel time is "<<tempd<<"\n\n";
//    
//    if(tempd < distance && tempd > 0)
//    {
//        distance = tempd;
//        ret = temp; 
//    }
//    
//
//
//}
//    cout<<"minimum travel time is "<<distance<<"\n\n";
//    return ret;

unsigned find_closest_point_of_interest_by_name(LatLon my_position, std::string POI_Name) {
    //Compute distance between myPosition and PointOfInterest(0)

    double distance = DBL_MAX;

    unsigned nearestPointID = DBL_MAX;
    //Compute distance between myPosition and all points of interest in the 
    //city 
    int const numPtsOfInterest = (int) numOfPOI;
    for (int i = 0; i < numPtsOfInterest; i++) {
        if (getPointOfInterestName(i) == POI_Name) {
            double intermediate = find_distance_squared_between_two_points(my_position,
                    getPointOfInterestPosition(i));

            if (intermediate == 0) {
                return i;
            }//If calculated distance in this iteration is less than current value
                //of distance, update the distance value and the ID value 
            else if (intermediate < distance) {
                distance = intermediate;
                nearestPointID = i;
            }
        }
    }
    //Return ID of the nearest point of interest with the specified name to the
    //provided location 
    return nearestPointID;

}

vector<unsigned> find_all_closest_point_of_interest_by_name(LatLon my_position, std::string POI_Name) {
    //Compute distance between myPosition and PointOfInterest(0)

    vector <unsigned> POIID;
    int const numPtsOfInterest = (int) numOfPOI;
    for (int i = 0; i < numPtsOfInterest; i++) {
        if (getPointOfInterestName(i) == POI_Name) {
            POIID.push_back(i);

        }
    }
    //Return ID of the nearest point of interest with the specified name to the
    //provided location 
    return POIID;
}

//Helper function for showing directions

std::vector<unsigned> find_path_between_intersections_for_showing_directions(unsigned
        intersect_id_start, unsigned intersect_id_end, vector<unsigned> & InterIDVec) {

    vector <int> interId_To_Parent_InterIDVec(numOfIntersections, 0);
    vector <int> interId_To_SegIdParent_IDVec(numOfIntersections, 0);


    priority_queue < pairOfAdjId_traveTime, vector < pairOfAdjId_traveTime >, comparisonClass > PQ;

    set<pair<double, unsigned>> mySet; //keeping the node value first so min is first


    //created vector with total num Of intersections and INTMAX as initial value
    //    neighbourInfo fillInVec;


    //keeps track of node values
    vector <double> distRefVec(numOfIntersections, DBL_MAX);



    distRefVec[intersect_id_start] = 0.0;
    interId_to_Parent_Inter_Id[intersect_id_start] = -1;

    unsigned adjInterId, adjacentSegId;
    //this loop just pushes the adjacent nodes of the start intersection into heap with their values
    for (unsigned i = 0; i < djKGraph [intersect_id_start].size(); i++) {

        auto curGraphPair = djKGraph [intersect_id_start][i];

        adjInterId = curGraphPair.adj_IntersectionId;

        //segment that leads to neighbour from start inter id
        adjacentSegId = curGraphPair.segmentIdOfAdj;

        //unsigned adjacentSegid1_2 = segId_Between_two_Intersections(interId,adjInterId);


        double adjTravelTime = curGraphPair.travelTimeToAdj;

        double hValue = findHeuristic(adjInterId, intersect_id_end);


        double updatedValue = adjTravelTime + hValue;
        distRefVec[adjInterId] = updatedValue;


        PQ.push(make_pair(adjInterId, updatedValue));
        interId_to_Parent_Inter_Id[adjInterId] = intersect_id_start;

        interId_to_SegId_Parent_Inter_Id[adjInterId] = adjacentSegId;


    }

    //we have inserted some initial adjacent intersections in heap from source id
    //now that we processed all adjacent intersections from source start processing
    //the min ids from heap

    while (!PQ.empty()) {

        //        cout << "entered heap loop\n";
        pair <unsigned, double> pairFromHeap = PQ.top();
        //auto setIterator = mySet.begin();

        //pair <double, unsigned> pairFromMySet = (*setIterator);
        //        cout << "\nPopped pair\n";
        //
        unsigned interIdFromHeap = pairFromHeap.first;

        double adjIdTravelTimeFromHeap = pairFromHeap.second;



        PQ.pop(); // remove the top element

        //now process the neighbour intersections of the pair id


        if (interIdFromHeap == intersect_id_end && adjIdTravelTimeFromHeap != DBL_MAX) {

            //found target node
            vector<unsigned> tracedBackPath;

            tracedBackPath = reTracePath(intersect_id_start, interIdFromHeap, interId_To_Parent_InterIDVec);
            InterIDVec = tracedBackPath;


            pair <unsigned, unsigned> myP;

            vector <unsigned> retVec;
            vector <unsigned> retVec1;

            vector <unsigned> retVec3;

            for (unsigned i = 0; i < tracedBackPath.size() - 1; i++) {

                myP.first = tracedBackPath[i];

                myP.second = tracedBackPath[i + 1];

                //1st retrace method-----------------------
                //using the retracing from the parent segId Map giving the intersection of next index
                retVec.push_back(interId_to_SegId_Parent_Inter_Id.at(myP.second));


                //                // 3rd retrace method --------------------------
                auto it = segId_Between_two_Intersections1(myP.first, myP.second);
                retVec3.push_back(it);

            }
            //
            double travelTime, travelTime2, travelTime3;
            travelTime = compute_path_travel_time(retVec);
            //travelTime2 = compute_path_travel_time(retVec1);
            travelTime3 = compute_path_travel_time(retVec3);



            //   cout << "----------------------\n";
            //          cout << "\ntarget time of retVec: " << travelTime << endl;
            //cout << "target time of travelTime2: " << travelTime2 << endl;
            //            cout << "target time of travelTime3: " << travelTime3 << endl;
            //  cout << "----------------------\n";


            if (travelTime < travelTime3) {
                return retVec;
            } else {
                return retVec3;
            }

        }
        //else keep on searching and if you reach the end of heap and then hit the target that will have inf then no path



        pair <unsigned, unsigned> interIdsPair;
        //segment 1 is from parent of the current node to the current node 
        //get street id1 from segid 1

        //grabbing the parent intersecion of the id you just popped from the heap


        //getting the segment id of current intersection parent's  &  current intersection
        //getting the parent of popped intersection
        interIdsPair.first = interId_to_Parent_Inter_Id.at(interIdFromHeap); //interId_to_Parent_Inter_Id.at(interIdFromHeap); //got A

        //the id of popped intersection 
        interIdsPair.second = interIdFromHeap; //got B

        //getting seg id b/w the parent and the node popped node
        unsigned segId1_2 = segId_Between_two_Intersections1(interIdsPair.first, interIdsPair.second);
        StreetSegmentInfo segInfo1 = streetSegmentInformationVec[segId1_2];
        unsigned streetIdFromSegId1 = segInfo1.streetID;





        unsigned parentOfcurInter = interId_to_Parent_Inter_Id.at(interIdFromHeap);



        auto parentVec = djKGraph.at(parentOfcurInter);
        unsigned streetId1;
        //got parent vector want to get the street id of parent->current intersection
        for (unsigned a = 0; a < parentVec.size(); a++) {
            if (parentVec[a].adj_IntersectionId == interIdFromHeap) {
                streetId1 = parentVec[a].streetIdOfAdj;

            }

        }







        //StreetSegmentInfo segInfo = streetSegmentInformationVec[segId];

        //unsigned streetIdFromSegId = segInfo.streetID; //street id from A-B


        //        if(segId  == 129350){
        //            cout << "previous road had streetId: "<<streetIdFromSegId<<endl;
        //        }

        auto it2 = djKGraph.find(interIdFromHeap);

        //--------------------------------------------------------------------------------------

        //vector to track which path you will take and don't include the offsets to them when pushing into heap

        //  vector < pair<unsigned, double> > neighbourReferenceVec;

        //keeps track of neighbours from heap that we are going to process checking if offset was added to them or not
        //
        //vector <neighbourInfo> neighbourRefVec(djKGraph.at(interIdFromHeap).size(), fillInVec);




        if (it2 != djKGraph.end()) {//safe check to avoid exception throw from djk in case no adjacent exits for an intersection like 3116 in toronto


            //get the adjacent intersections of the popped intersection and calculate the values of them
            for (unsigned i = 0; i < djKGraph.at(interIdFromHeap).size(); i++) {


                //got the ith negigbour of intersection gotten from heap
                auto curGraphPair = djKGraph.at(interIdFromHeap)[i];

                unsigned adjacentSegId = curGraphPair.segmentIdOfAdj;

                unsigned adjInterId = curGraphPair.adj_IntersectionId; // C

                double adjTravelTime = curGraphPair.travelTimeToAdj;

                unsigned streetId2 = curGraphPair.streetIdOfAdj;

                //check for target is neighbour
                if (adjInterId == intersect_id_end) {
                    //neighbour is the target

                }


                //                if (adjInterId == 86467) {
                //                    cout << "\nstreetId2 for intersection 86467: " << streetId2;
                //                    cout << "  adjInterId: " << adjInterId << endl;
                //                }


                double hValue = findHeuristic(adjInterId, intersect_id_end);


                //double updatedValue = adjTravelTime + hValue;
                //distRefVec[adjInterId] = updatedValue;



                double distFromRefVecofAdj = distRefVec[adjInterId]; //need to be of the main node you are processing from 

                double distFromRefVecofMainNode = distRefVec[interIdFromHeap];


                unsigned segId2 = segId_Between_two_Intersections1(interIdFromHeap, adjInterId);


                StreetSegmentInfo segInfo2 = streetSegmentInformationVec[segId2];
                //

                unsigned streetIdFromSegId2 = segInfo2.streetID;

                //                if (segId2 == 109789) {
                //                    cout << "109789 segId has street ID: " << streetIdFromSegId2 << endl;
                //                }
                //
                //                if (segId2 == 129351) {
                //                    cout << "129351 segId has street ID: " << streetIdFromSegId2 << endl;
                //                }


                //fist 2 are g costs and then add h value
                double newVal = distFromRefVecofMainNode + adjTravelTime + hValue;
                double newVaue_Old_Method = distFromRefVecofMainNode + adjTravelTime + hValue;
                //
                if (streetIdFromSegId1 != streetIdFromSegId2) {
                    newVaue_Old_Method = newVaue_Old_Method + 0.25;
                } else {

                }


                if (streetId1 != streetId2) {
                    //if (streetIdFromSegId1 != streetIdFromSegId2) {
                    //add 15s offset to new val
                    //                    cout << "diff seg id found for this adj id,adding offset\n";

                    newVal = newVal + 0.25; //\\\(15.0 / 60.0);

                    //                    if (adjInterId == 86467) {
                    //                        cout << "\n-----------------------------\n";
                    //                        cout << "newValue of 86467: " << newVal;
                    //
                    //                    }
                    //storing for potential offsets

                } else {

                    //                    if (adjInterId == 86467) {
                    //                        cout << "\n-----------------------------\n";
                    //                        cout << "newValue of 86467: " << newVal;
                    //
                    //                    }

                    //didn't mark added offset
                }


                //vector that keeps track of neighbours processed of the main node
                //                neighbourReferenceVec.push_back(make_pair(adjInterId, newVal));


                //after this loop we have all the nodes processed with possible offsets to them
                //            //now we select node with smallest value and add offset to that and remove offset from rest and then push all of them into heap
                //            pair<unsigned, double> smallestPair = neighbourReferenceVec[0];
                //            for (unsigned m = 1; m < neighbourReferenceVec.size(); m++) {
                //                pair<unsigned, double> curPair = neighbourReferenceVec[m];
                //
                //
                //
                //                if (smallestPair.second > curPair.second) {
                //                    smallestPair = curPair;
                //                }
                //            }
                //            for (unsigned k = 0; k < neighbourReferenceVec.size(); k++) {
                //                if(smallestPair.first != neighbourReferenceVec[k].first){
                //                    //remove the offsets if were added!!! from intersections you didn't choose as you chose the smallestPair
                //                    
                //                }
                //                        
                //
                //            }

                //search thru refVec, get the value of adjInterId in their if its less than already present

                //need to account for 15s offset before doing this
                if (newVaue_Old_Method < newVal) {
                    newVal = newVaue_Old_Method;
                }





                if (newVal < distFromRefVecofAdj) {

                    //update the value in the ref Vector
                    distRefVec[adjInterId] = newVal;

                    //                    if (adjInterId == 86467) {
                    //                        cout << "1. 86467 processed: " << distRefVec[adjInterId] << endl;
                    //                    }

                    //
                    //                    cout << "dist in desitRefvector after update at adjInterID: " << distRefVec[adjInterId] << endl;
                    //
                    //
                    //                    cout << "pushing lessVal into heap\n";
                    //                    //change the value in the queue


                    //                    mySet.insert((make_pair(newVal, adjInterId)));
                    PQ.push(make_pair(adjInterId, newVal));
                    //
                    //                    cout << "newParent: " << interIdFromHeap << "of Node: " << adjInterId << endl;
                    //setting the parent of the current processed adjacent intersection to outter heap processed inter id
                    interId_to_Parent_Inter_Id[adjInterId] = interIdFromHeap;

                    interId_to_SegId_Parent_Inter_Id[adjInterId] = adjacentSegId;


                } else {

                    //                    cout << "new Val wasn't < value in ref vector so didn't update parent, didn't push in heap and didn't update parent\n\n";

                }



            }




        }






    }

    //we checked all inter ids pair from heap and couldn't find the target with non inf so that means path doesn't exists!!!!!!!!!
    //put the empty vector of segids to return in this case

    //    cout << "path not found heap got empty\n";
    vector <unsigned> empVec;
    return empVec;







}
