#include "StreetsDatabaseAPI.h"
#include "m1.h"
#include "m2.h"
#include "OSMDatabaseAPI.h"
#include "../../libstreetmap/src/mapLoder.h"

using namespace std;

//Note for TA: Before running this project change the output to external terminal from project properties->run
// Place the terminal and the graphics window side by side to see the proper drawing operations
//Thanks
int main() {

   mapInitializer();

    return 0;
}
